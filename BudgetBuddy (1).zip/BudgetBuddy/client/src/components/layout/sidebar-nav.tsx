import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Briefcase, 
  Users, 
  Settings, 
  BarChart3, 
  HelpCircle 
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Projects", href: "/projects", icon: Briefcase },
  { name: "Resources", href: "/resources", icon: Users },
  { name: "Analytics", href: "/analytics", icon: BarChart3, disabled: true },
  { name: "Settings", href: "/settings", icon: Settings, disabled: true },
  { name: "Help", href: "/help", icon: HelpCircle, disabled: true },
];

export default function SidebarNav() {
  const [location] = useLocation();

  return (
    <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-60 lg:flex-col bg-sidebar border-r border-sidebar-border">
      <div className="flex grow flex-col gap-y-5 overflow-y-auto px-6 py-4">
        <div className="flex h-16 shrink-0 items-center">
          <h1 className="text-xl font-bold text-sidebar-foreground">
            FinBudget Pro
          </h1>
        </div>
        <nav className="flex flex-1 flex-col">
          <ul role="list" className="flex flex-1 flex-col gap-y-7">
            <li>
              <ul role="list" className="space-y-1">
                {navigation.map((item) => (
                  <li key={item.name}>
                    {item.disabled ? (
                      <span 
                        className={cn(
                          "group flex gap-x-3 rounded-md p-2 text-sm font-semibold leading-6 text-muted-foreground cursor-not-allowed opacity-50"
                        )}
                      >
                        <item.icon className="h-6 w-6 shrink-0" aria-hidden="true" />
                        {item.name}
                      </span>
                    ) : (
                      <Link 
                        href={item.href}
                        className={cn(
                          "group flex gap-x-3 rounded-md p-2 text-sm font-semibold leading-6",
                          location === item.href 
                            ? "bg-sidebar-primary text-sidebar-primary-foreground" 
                            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                        )}
                      >
                        <item.icon className="h-6 w-6 shrink-0" aria-hidden="true" />
                        {item.name}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </li>
            <li className="mt-auto">
              <div className="flex items-center gap-x-4 py-3 text-sm font-semibold leading-6 text-gray-400">
                <span className="text-xs font-normal leading-none text-muted-foreground">
                  &copy; {new Date().getFullYear()} FinBudget Pro
                </span>
              </div>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}
