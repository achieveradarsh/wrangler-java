import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { expenseFormSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface ExpenseCategory {
  id: number;
  name: string;
}

interface ExpenseFormProps {
  projectId: number;
  expense?: {
    id: number;
    amount: number;
    categoryId: number;
    description: string | null;
    date: string;
  };
  categories?: ExpenseCategory[];
  onSuccess: () => void;
}

type FormValues = z.infer<typeof expenseFormSchema>;

export default function ExpenseForm({ projectId, expense, categories, onSuccess }: ExpenseFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get the current user (for now we'll just use a placeholder user ID)
  const currentUserId = 1;
  
  const form = useForm<FormValues>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      projectId,
      categoryId: expense?.categoryId || (categories && categories.length > 0 ? categories[0].id : 1),
      amount: expense?.amount || 0,
      description: expense?.description || "",
      date: expense?.date ? new Date(expense.date) : new Date(),
      createdBy: currentUserId,
    },
  });
  
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      return apiRequest("POST", "/api/expenses", values);
    },
    onSuccess: () => {
      toast({
        title: "Expense added",
        description: "The expense has been added successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/expenses`] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/budget-summary"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to add expense",
        description: error.message || "An error occurred while adding the expense.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!expense) return null;
      return apiRequest("PUT", `/api/expenses/${expense.id}`, values);
    },
    onSuccess: () => {
      toast({
        title: "Expense updated",
        description: "The expense has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/expenses`] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/budget-summary"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update expense",
        description: error.message || "An error occurred while updating the expense.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  async function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    
    if (expense) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="categoryId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Expense Category</FormLabel>
              <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id.toString()}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Amount ($)</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  min="0" 
                  step="0.01" 
                  placeholder="Enter amount" 
                  {...field}
                  onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description (optional)</FormLabel>
              <FormControl>
                <Textarea placeholder="Enter expense description" rows={3} {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Date</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant="outline"
                      className={cn(
                        "pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value ? (
                        format(field.value, "PPP")
                      ) : (
                        <span>Pick a date</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onSuccess}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : expense ? 'Update Expense' : 'Add Expense'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
