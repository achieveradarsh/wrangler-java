/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.wrangler.api.parser;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ByteSize provides a way to parse and handle byte size representations like 1KB, 2MB, etc.
 * This class parses the input string and converts it to a canonical value in bytes.
 */
public class ByteSize implements Token {
  // Pattern for matching byte size values (e.g., 10KB, 5MB, 2.5GB)
  private static final Pattern BYTE_SIZE_PATTERN = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(B|KB|MB|GB|TB|PB)?", 
                                                                  Pattern.CASE_INSENSITIVE);
  
  // Conversion factors for different byte size units to bytes
  private static final Map<String, Double> UNIT_TO_BYTES_FACTOR = new HashMap<>();
  static {
    UNIT_TO_BYTES_FACTOR.put("B", 1.0);
    UNIT_TO_BYTES_FACTOR.put("KB", 1024.0);
    UNIT_TO_BYTES_FACTOR.put("MB", 1024.0 * 1024.0);
    UNIT_TO_BYTES_FACTOR.put("GB", 1024.0 * 1024.0 * 1024.0);
    UNIT_TO_BYTES_FACTOR.put("TB", 1024.0 * 1024.0 * 1024.0 * 1024.0);
    UNIT_TO_BYTES_FACTOR.put("PB", 1024.0 * 1024.0 * 1024.0 * 1024.0 * 1024.0);
  }

  private final String originalValue;
  private final double value;
  private final String unit;
  private final double bytes;

  /**
   * Constructor to create a ByteSize object from a string representation.
   *
   * @param value String representation of byte size (e.g., "10KB", "5MB")
   */
  public ByteSize(String value) {
    this.originalValue = value;
    
    Matcher matcher = BYTE_SIZE_PATTERN.matcher(value.trim());
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid byte size format: " + value);
    }
    
    this.value = Double.parseDouble(matcher.group(1));
    this.unit = (matcher.group(2) != null) ? matcher.group(2).toUpperCase() : "B";
    
    Double factor = UNIT_TO_BYTES_FACTOR.get(this.unit);
    if (factor == null) {
      throw new IllegalArgumentException("Unknown byte size unit: " + this.unit);
    }
    
    this.bytes = this.value * factor;
  }

  /**
   * Gets the original string value.
   *
   * @return the original string representation of the byte size
   */
  public String getOriginalValue() {
    return originalValue;
  }

  /**
   * Gets the numeric value part of the byte size.
   *
   * @return the numeric value
   */
  public double getValue() {
    return value;
  }

  /**
   * Gets the unit part of the byte size (e.g., "KB", "MB").
   *
   * @return the unit
   */
  public String getUnit() {
    return unit;
  }

  /**
   * Gets the byte size in bytes.
   *
   * @return the size in bytes
   */
  public double getBytes() {
    return bytes;
  }

  /**
   * Gets the byte size in kilobytes.
   *
   * @return the size in kilobytes
   */
  public double getKilobytes() {
    return bytes / UNIT_TO_BYTES_FACTOR.get("KB");
  }

  /**
   * Gets the byte size in megabytes.
   *
   * @return the size in megabytes
   */
  public double getMegabytes() {
    return bytes / UNIT_TO_BYTES_FACTOR.get("MB");
  }

  /**
   * Gets the byte size in gigabytes.
   *
   * @return the size in gigabytes
   */
  public double getGigabytes() {
    return bytes / UNIT_TO_BYTES_FACTOR.get("GB");
  }

  /**
   * Gets the byte size in terabytes.
   *
   * @return the size in terabytes
   */
  public double getTerabytes() {
    return bytes / UNIT_TO_BYTES_FACTOR.get("TB");
  }

  /**
   * Gets the byte size in petabytes.
   *
   * @return the size in petabytes
   */
  public double getPetabytes() {
    return bytes / UNIT_TO_BYTES_FACTOR.get("PB");
  }

  /**
   * Gets the byte size in the specified unit.
   *
   * @param unit the unit to convert to (B, KB, MB, GB, TB, PB)
   * @return the size in the specified unit
   */
  public double getAs(String unit) {
    Double factor = UNIT_TO_BYTES_FACTOR.get(unit.toUpperCase());
    if (factor == null) {
      throw new IllegalArgumentException("Unknown byte size unit: " + unit);
    }
    return bytes / factor;
  }

  /**
   * Formats the byte size as a string with the specified unit.
   *
   * @param unit the unit to use for formatting
   * @return a formatted string representation
   */
  public String format(String unit) {
    return String.format("%.2f%s", getAs(unit), unit);
  }

  @Override
  public TokenType type() {
    return TokenType.BYTE_SIZE;
  }

  @Override
  public String toString() {
    return originalValue;
  }
  
  @Override
  public JsonElement toJson() {
    JsonObject object = new JsonObject();
    object.addProperty("type", type().name());
    object.addProperty("value", originalValue);
    object.addProperty("bytes", bytes);
    object.addProperty("unit", unit);
    return object;
  }
}