/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.directives.aggregator;

import com.google.common.collect.ImmutableList;
import io.cdap.cdap.api.annotation.Description;
import io.cdap.cdap.api.annotation.Name;
import io.cdap.cdap.api.annotation.Plugin;
import io.cdap.wrangler.api.Arguments;
import io.cdap.wrangler.api.Directive;
import io.cdap.wrangler.api.DirectiveExecutionException;
import io.cdap.wrangler.api.DirectiveParseException;
import io.cdap.wrangler.api.EntityCountMetric;
import io.cdap.wrangler.api.ExecutorContext;
import io.cdap.wrangler.api.Row;
import io.cdap.wrangler.api.TransientStore;
import io.cdap.wrangler.api.TransientVariableScope;
import io.cdap.wrangler.api.annotations.Categories;
import io.cdap.wrangler.api.parser.ByteSize;
import io.cdap.wrangler.api.parser.ColumnName;
import io.cdap.wrangler.api.parser.Text;
import io.cdap.wrangler.api.parser.TimeDuration;
import io.cdap.wrangler.api.parser.TokenType;
import io.cdap.wrangler.api.parser.UsageDefinition;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A directive for aggregating statistics on columns containing byte sizes and time durations.
 * This directive accumulates minimum, maximum, sum, count, and average values for specified columns.
 */
@Plugin(type = Directive.TYPE)
@Name(AggregateStats.NAME)
@Categories(categories = {"aggregator"})
@Description("Aggregates statistics on columns containing byte sizes and time durations.")
public class AggregateStats implements Directive {
  public static final String NAME = "aggregate-stats";
  private String column;
  private String statsPrefix;
  private StatsType statsType;

  /**
   * Enumeration of supported statistics types.
   */
  private enum StatsType {
    BYTE_SIZE("bytesize"),
    TIME_DURATION("timeduration");

    private final String value;

    StatsType(String value) {
      this.value = value;
    }

    public static StatsType fromString(String typeStr) {
      for (StatsType type : StatsType.values()) {
        if (type.value.equalsIgnoreCase(typeStr)) {
          return type;
        }
      }
      throw new IllegalArgumentException("Unknown stats type: " + typeStr);
    }
  }

  /**
   * Defines the usage pattern for the directive.
   */
  @Override
  public UsageDefinition define() {
    UsageDefinition.Builder builder = UsageDefinition.builder(NAME);
    builder.define("column", TokenType.COLUMN_NAME);
    builder.define("type", TokenType.TEXT);
    builder.define("prefix", TokenType.TEXT);
    return builder.build();
  }

  /**
   * Initializes the directive with the provided arguments.
   */
  @Override
  public void initialize(Arguments args) throws DirectiveParseException {
    this.column = ((ColumnName) args.value("column")).value();
    String typeStr = ((Text) args.value("type")).value();
    this.statsPrefix = ((Text) args.value("prefix")).value();
    
    try {
      this.statsType = StatsType.fromString(typeStr);
    } catch (IllegalArgumentException e) {
      throw new DirectiveParseException(
        NAME, String.format("Invalid stats type '%s'. Supported types are 'bytesize' and 'timeduration'.", typeStr));
    }
  }

  /**
   * Executes the directive on the input rows.
   */
  @Override
  public List<Row> execute(List<Row> rows, ExecutorContext context) throws DirectiveExecutionException {
    if (context == null || context.getTransientStore() == null) {
      throw new DirectiveExecutionException(NAME, "Transient store is not available.");
    }

    TransientStore store = context.getTransientStore();
    
    for (Row row : rows) {
      Object value = row.getValue(column);
      if (value == null) {
        continue;
      }
      
      try {
        switch (statsType) {
          case BYTE_SIZE:
            processByteSizeValue(value, store);
            break;
          case TIME_DURATION:
            processTimeDurationValue(value, store);
            break;
          default:
            throw new DirectiveExecutionException(NAME, "Unsupported stats type: " + statsType);
        }
      } catch (Exception e) {
        throw new DirectiveExecutionException(NAME, 
          String.format("Error processing value '%s' in column '%s': %s", value, column, e.getMessage()), e);
      }
    }
    
    // Add aggregated statistics to the last row
    if (!rows.isEmpty()) {
      Row lastRow = rows.get(rows.size() - 1);
      addStatisticsToRow(lastRow, store);
    }
    
    return rows;
  }

  /**
   * Processes a byte size value and updates the statistics in the transient store.
   */
  private void processByteSizeValue(Object value, TransientStore store) throws DirectiveExecutionException {
    ByteSize byteSize;
    if (value instanceof ByteSize) {
      byteSize = (ByteSize) value;
    } else if (value instanceof String) {
      try {
        byteSize = new ByteSize(value.toString());
      } catch (IllegalArgumentException e) {
        throw new DirectiveExecutionException(NAME, 
          String.format("Invalid byte size value '%s': %s", value, e.getMessage()), e);
      }
    } else {
      throw new DirectiveExecutionException(NAME, 
        String.format("Cannot convert value of type '%s' to ByteSize", value.getClass().getName()));
    }
    
    double bytes = byteSize.getBytes();
    
    // Increment count
    String countKey = statsPrefix + ".count";
    Long count = store.get(countKey);
    if (count == null) {
      count = 0L;
    }
    store.set(TransientVariableScope.GLOBAL, countKey, count + 1);
    
    // Update sum
    String sumKey = statsPrefix + ".sum";
    Double sum = store.get(sumKey);
    if (sum == null) {
      sum = 0.0;
    }
    store.set(TransientVariableScope.GLOBAL, sumKey, sum + bytes);
    
    // Update min
    String minKey = statsPrefix + ".min";
    Double min = store.get(minKey);
    if (min == null || bytes < min) {
      store.set(TransientVariableScope.GLOBAL, minKey, bytes);
    }
    
    // Update max
    String maxKey = statsPrefix + ".max";
    Double max = store.get(maxKey);
    if (max == null || bytes > max) {
      store.set(TransientVariableScope.GLOBAL, maxKey, bytes);
    }
  }

  /**
   * Processes a time duration value and updates the statistics in the transient store.
   */
  private void processTimeDurationValue(Object value, TransientStore store) throws DirectiveExecutionException {
    TimeDuration timeDuration;
    if (value instanceof TimeDuration) {
      timeDuration = (TimeDuration) value;
    } else if (value instanceof String) {
      try {
        timeDuration = new TimeDuration(value.toString());
      } catch (IllegalArgumentException e) {
        throw new DirectiveExecutionException(NAME, 
          String.format("Invalid time duration value '%s': %s", value, e.getMessage()), e);
      }
    } else {
      throw new DirectiveExecutionException(NAME, 
        String.format("Cannot convert value of type '%s' to TimeDuration", value.getClass().getName()));
    }
    
    double ms = timeDuration.getMilliseconds();
    
    // Increment count
    String countKey = statsPrefix + ".count";
    Long count = store.get(countKey);
    if (count == null) {
      count = 0L;
    }
    store.set(TransientVariableScope.GLOBAL, countKey, count + 1);
    
    // Update sum
    String sumKey = statsPrefix + ".sum";
    Double sum = store.get(sumKey);
    if (sum == null) {
      sum = 0.0;
    }
    store.set(TransientVariableScope.GLOBAL, sumKey, sum + ms);
    
    // Update min
    String minKey = statsPrefix + ".min";
    Double min = store.get(minKey);
    if (min == null || ms < min) {
      store.set(TransientVariableScope.GLOBAL, minKey, ms);
    }
    
    // Update max
    String maxKey = statsPrefix + ".max";
    Double max = store.get(maxKey);
    if (max == null || ms > max) {
      store.set(TransientVariableScope.GLOBAL, maxKey, ms);
    }
  }

  /**
   * Adds the calculated statistics to the specified row.
   */
  private void addStatisticsToRow(Row row, TransientStore store) {
    String countKey = statsPrefix + ".count";
    String sumKey = statsPrefix + ".sum";
    String minKey = statsPrefix + ".min";
    String maxKey = statsPrefix + ".max";
    
    Long count = store.get(countKey);
    Double sum = store.get(sumKey);
    Double min = store.get(minKey);
    Double max = store.get(maxKey);
    
    if (count == null || count == 0) {
      // No data processed, don't add statistics
      return;
    }
    
    double avg = (sum != null && count > 0) ? sum / count : 0.0;
    
    // Add statistics to the row with appropriate formatting
    switch (statsType) {
      case BYTE_SIZE:
        // Format as byte size values
        row.addOrSet(statsPrefix + ".count", count);
        row.addOrSet(statsPrefix + ".sum", formatByteSize(sum));
        row.addOrSet(statsPrefix + ".min", formatByteSize(min));
        row.addOrSet(statsPrefix + ".max", formatByteSize(max));
        row.addOrSet(statsPrefix + ".avg", formatByteSize(avg));
        break;
        
      case TIME_DURATION:
        // Format as time duration values
        row.addOrSet(statsPrefix + ".count", count);
        row.addOrSet(statsPrefix + ".sum", formatTimeDuration(sum));
        row.addOrSet(statsPrefix + ".min", formatTimeDuration(min));
        row.addOrSet(statsPrefix + ".max", formatTimeDuration(max));
        row.addOrSet(statsPrefix + ".avg", formatTimeDuration(avg));
        break;
    }
  }

  /**
   * Formats a byte size value based on its magnitude.
   */
  private String formatByteSize(Double bytes) {
    if (bytes == null) {
      return null;
    }
    
    String unit;
    double value;
    
    if (bytes < 1024) {
      unit = "B";
      value = bytes;
    } else if (bytes < 1024 * 1024) {
      unit = "KB";
      value = bytes / 1024.0;
    } else if (bytes < 1024 * 1024 * 1024) {
      unit = "MB";
      value = bytes / (1024.0 * 1024.0);
    } else if (bytes < 1024.0 * 1024.0 * 1024.0 * 1024.0) {
      unit = "GB";
      value = bytes / (1024.0 * 1024.0 * 1024.0);
    } else {
      unit = "TB";
      value = bytes / (1024.0 * 1024.0 * 1024.0 * 1024.0);
    }
    
    return String.format("%.2f %s", value, unit);
  }

  /**
   * Formats a time duration value based on its magnitude.
   */
  private String formatTimeDuration(Double ms) {
    if (ms == null) {
      return null;
    }
    
    String unit;
    double value;
    
    if (ms < 1) {
      unit = "ns";
      value = ms * 1_000_000;
    } else if (ms < 1000) {
      unit = "ms";
      value = ms;
    } else if (ms < 60 * 1000) {
      unit = "s";
      value = ms / 1000.0;
    } else if (ms < 60 * 60 * 1000) {
      unit = "min";
      value = ms / (60 * 1000.0);
    } else if (ms < 24 * 60 * 60 * 1000) {
      unit = "h";
      value = ms / (60 * 60 * 1000.0);
    } else {
      unit = "d";
      value = ms / (24 * 60 * 60 * 1000.0);
    }
    
    return String.format("%.2f %s", value, unit);
  }

  @Override
  public void destroy() {
    // No resources to clean up
  }

  @Override
  public List<EntityCountMetric> getCountMetrics() {
    return null;
  }
}