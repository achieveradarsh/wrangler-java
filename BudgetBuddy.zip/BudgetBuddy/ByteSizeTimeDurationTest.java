import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ByteSizeTimeDurationTest {
    public static void main(String[] args) {
        System.out.println("Testing ByteSize and TimeDuration parsing...");
        
        // Test ByteSize
        testByteSize("10KB");
        testByteSize("1MB");
        testByteSize("2.5GB");
        
        // Test TimeDuration
        testTimeDuration("100ms");
        testTimeDuration("5s");
        testTimeDuration("2.5min");
    }
    
    // Simple ByteSize implementation for testing
    static void testByteSize(String input) {
        Pattern pattern = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(B|KB|MB|GB|TB|PB)?", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(input.trim());
        
        if (matcher.matches()) {
            double value = Double.parseDouble(matcher.group(1));
            String unit = (matcher.group(2) != null) ? matcher.group(2).toUpperCase() : "B";
            
            double bytes = convertToBytes(value, unit);
            
            System.out.println("ByteSize: " + input);
            System.out.println("  Value: " + value);
            System.out.println("  Unit: " + unit);
            System.out.println("  Bytes: " + bytes);
            System.out.println("  JSON would be: {\"type\":\"BYTE_SIZE\",\"value\":\"" + input + "\",\"bytes\":" + bytes + ",\"unit\":\"" + unit + "\"}");
            System.out.println();
        } else {
            System.out.println("Failed to parse: " + input);
        }
    }
    
    // Simple TimeDuration implementation for testing
    static void testTimeDuration(String input) {
        Pattern pattern = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(ns|ms|s|min|h|d)?", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(input.trim());
        
        if (matcher.matches()) {
            double value = Double.parseDouble(matcher.group(1));
            String unit = (matcher.group(2) != null) ? matcher.group(2).toUpperCase() : "MS";
            
            double ms = convertToMilliseconds(value, unit);
            
            System.out.println("TimeDuration: " + input);
            System.out.println("  Value: " + value);
            System.out.println("  Unit: " + unit);
            System.out.println("  Milliseconds: " + ms);
            System.out.println("  JSON would be: {\"type\":\"TIME_DURATION\",\"value\":\"" + input + "\",\"milliseconds\":" + ms + ",\"unit\":\"" + unit + "\"}");
            System.out.println();
        } else {
            System.out.println("Failed to parse: " + input);
        }
    }
    
    // Conversion helper for ByteSize
    static double convertToBytes(double value, String unit) {
        switch (unit) {
            case "B": return value;
            case "KB": return value * 1024;
            case "MB": return value * 1024 * 1024;
            case "GB": return value * 1024 * 1024 * 1024;
            case "TB": return value * 1024 * 1024 * 1024 * 1024;
            case "PB": return value * 1024 * 1024 * 1024 * 1024 * 1024;
            default: return value;
        }
    }
    
    // Conversion helper for TimeDuration
    static double convertToMilliseconds(double value, String unit) {
        switch (unit) {
            case "NS": return value * 0.000001;
            case "MS": return value;
            case "S": return value * 1000;
            case "MIN": return value * 60000;
            case "H": return value * 3600000;
            case "D": return value * 86400000;
            default: return value;
        }
    }
}