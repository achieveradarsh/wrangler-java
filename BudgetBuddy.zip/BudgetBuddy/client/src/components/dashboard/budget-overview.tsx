import { useEffect, useState } from "react";
import { BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Bar, Cell } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

interface Project {
  id: number;
  name: string;
  totalBudget: number;
}

interface ChartData {
  name: string;
  budget: number;
  expenses: number;
  remaining: number;
}

interface BudgetOverviewProps {
  isLoading: boolean;
  projects?: Project[];
}

export default function BudgetOverview({ isLoading, projects }: BudgetOverviewProps) {
  const [data, setData] = useState<ChartData[]>([]);

  useEffect(() => {
    if (projects && projects.length > 0) {
      // For demonstration, we're creating sample data
      // In a real scenario, you'd fetch the actual expenses data from the API
      const chartData = projects.slice(0, 5).map(project => {
        // Simulate expenses between 30-90% of budget
        const expensePercentage = 0.3 + Math.random() * 0.6;
        const expenses = project.totalBudget * expensePercentage;
        
        return {
          name: project.name.length > 20 ? project.name.substring(0, 20) + '...' : project.name,
          budget: project.totalBudget,
          expenses: expenses,
          remaining: project.totalBudget - expenses
        };
      });
      
      setData(chartData);
    } else {
      setData([]);
    }
  }, [projects]);

  if (isLoading) {
    return <Skeleton className="h-[350px] w-full" />;
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-[350px] border rounded-md border-dashed">
        <p className="text-muted-foreground">No project data available</p>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 60,
        }}
        barGap={0}
        barCategoryGap={20}
      >
        <XAxis
          dataKey="name"
          angle={-45}
          textAnchor="end"
          tick={{ fontSize: 12 }}
          interval={0}
          tickMargin={10}
        />
        <YAxis />
        <Tooltip 
          formatter={(value) => `$${Number(value).toLocaleString()}`} 
          labelFormatter={(label) => `Project: ${label}`}
        />
        <Bar name="Budget" dataKey="budget" fill="hsl(var(--chart-1))" />
        <Bar name="Expenses" dataKey="expenses" fill="hsl(var(--chart-2))" />
        <Bar name="Remaining" dataKey="remaining" fill="hsl(var(--chart-3))" />
      </BarChart>
    </ResponsiveContainer>
  );
}
