import { Link } from "wouter";
import { format } from "date-fns";
import { CalendarDays, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface Project {
  id: number;
  name: string;
  clientName: string;
  startDate: string;
  status: string;
}

interface RecentActivityProps {
  isLoading: boolean;
  projects?: Project[];
}

export default function RecentActivity({ isLoading, projects }: RecentActivityProps) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="bg-accent/20">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <Skeleton className="h-5 w-40" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-8 w-16" />
              </div>
              <div className="flex items-center mt-2 text-sm text-muted-foreground">
                <Skeleton className="h-4 w-[120px]" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!projects || projects.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-40 border rounded-md border-dashed">
        <p className="text-muted-foreground">No recent activity</p>
        <Link href="/projects">
          <Button variant="link" className="mt-2">
            Create your first project
          </Button>
        </Link>
      </div>
    );
  }

  const recentProjects = projects.slice(0, 5);

  return (
    <div className="space-y-4">
      {recentProjects.map((project) => (
        <Card key={project.id} className="bg-accent/20 hover:bg-accent/30 transition-colors">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h4 className="font-semibold leading-none">{project.name}</h4>
                <p className="text-sm text-muted-foreground">Client: {project.clientName}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                project.status === 'active' 
                  ? 'bg-green-100 text-green-800' 
                  : project.status === 'on-hold'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-blue-100 text-blue-800'
              }`}>
                {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
              </span>
            </div>
            <div className="flex items-center mt-2 text-sm text-muted-foreground">
              <CalendarDays className="mr-1 h-3 w-3" />
              <span>
                Started on {format(new Date(project.startDate), 'MMM d, yyyy')}
              </span>
            </div>
            <div className="mt-3 flex justify-end">
              <Link href={`/projects/${project.id}`}>
                <Button variant="ghost" size="sm" className="px-2">
                  <span className="text-xs">View details</span>
                  <ArrowRight className="ml-1 h-3 w-3" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {recentProjects.length > 0 && (
        <div className="flex justify-center mt-4">
          <Link href="/projects">
            <Button variant="outline" size="sm" className="w-full">
              View all projects
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
