import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

interface UtilizationData {
  resourceId: number;
  resourceName: string;
  allocatedHours: number;
  availableHours: number;
  utilizationPercentage: number;
}

interface ResourceUtilizationProps {
  isLoading: boolean;
  utilization?: UtilizationData[];
}

// These colors should match your theme.json primary and other thematic colors
const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

export default function ResourceUtilization({ isLoading, utilization }: ResourceUtilizationProps) {
  if (isLoading) {
    return <Skeleton className="h-[300px] w-full" />;
  }

  if (!utilization || utilization.length === 0) {
    return (
      <div className="flex items-center justify-center h-[300px] border rounded-md border-dashed">
        <p className="text-muted-foreground">No resource data available</p>
      </div>
    );
  }

  // Prepare data for the pie chart
  const chartData = utilization.map(item => ({
    name: item.resourceName,
    value: item.utilizationPercentage
  }));

  // Calculate average utilization
  const avgUtilization = utilization.reduce(
    (sum, item) => sum + item.utilizationPercentage, 0
  ) / utilization.length;

  return (
    <div className="w-full">
      <div className="mb-4 text-center">
        <div className="text-2xl font-bold">{avgUtilization.toFixed(1)}%</div>
        <p className="text-xs text-muted-foreground">Average resource utilization</p>
      </div>
      
      <ResponsiveContainer width="100%" height={200}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={80}
            fill="#8884d8"
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value) => `${Number(value).toFixed(1)}%`}
            labelFormatter={(label) => `Resource: ${label}`}
          />
          <Legend layout="horizontal" verticalAlign="bottom" align="center" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
