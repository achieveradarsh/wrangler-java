import { useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

type ExportType = 'projects' | 'expenses' | 'resources' | 'resource-allocations';

export default function ExportButton() {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async (type: ExportType) => {
    setIsExporting(true);
    try {
      // Create a temporary anchor to trigger the download
      const a = document.createElement('a');
      a.href = `/api/export/${type}`;
      a.download = `${type}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      toast({
        title: "Export successful",
        description: `${type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' ')} data has been exported`,
      });
    } catch (error) {
      console.error(`Error exporting ${type}:`, error);
      toast({
        variant: "destructive",
        title: "Export failed",
        description: `Could not export ${type.replace('-', ' ')} data. Please try again.`,
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-2" 
          disabled={isExporting}
        >
          <Download className="h-4 w-4" />
          <span>Export</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => handleExport('projects')}>
          Export Projects
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('expenses')}>
          Export Expenses
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('resources')}>
          Export Resources
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('resource-allocations')}>
          Export Resource Allocations
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
