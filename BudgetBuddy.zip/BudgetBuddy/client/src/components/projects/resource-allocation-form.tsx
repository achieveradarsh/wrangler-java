import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { resourceAllocationFormSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface Resource {
  id: number;
  name: string;
  role: string;
  hourlyRate: number;
}

interface ResourceAllocationFormProps {
  projectId: number;
  allocation?: {
    id: number;
    resourceId: number;
    hours: number;
    startDate: string;
    endDate: string | null;
    notes: string | null;
  };
  resources?: Resource[];
  onSuccess: () => void;
}

type FormValues = z.infer<typeof resourceAllocationFormSchema>;

export default function ResourceAllocationForm({ projectId, allocation, resources, onSuccess }: ResourceAllocationFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(resourceAllocationFormSchema),
    defaultValues: {
      projectId,
      resourceId: allocation?.resourceId || (resources && resources.length > 0 ? resources[0].id : 1),
      hours: allocation?.hours || 0,
      startDate: allocation?.startDate ? new Date(allocation.startDate) : new Date(),
      endDate: allocation?.endDate ? new Date(allocation.endDate) : undefined,
      notes: allocation?.notes || "",
    },
  });
  
  const [selectedResource, setSelectedResource] = useState<Resource | undefined>(
    resources?.find(r => r.id === (allocation?.resourceId || (resources && resources.length > 0 ? resources[0].id : 1)))
  );
  
  const handleResourceChange = (resourceId: number) => {
    const resource = resources?.find(r => r.id === resourceId);
    setSelectedResource(resource);
  };
  
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      return apiRequest("POST", "/api/resource-allocations", values);
    },
    onSuccess: () => {
      toast({
        title: "Resource allocated",
        description: "The resource has been allocated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/resource-allocations`] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to allocate resource",
        description: error.message || "An error occurred while allocating the resource.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!allocation) return null;
      return apiRequest("PUT", `/api/resource-allocations/${allocation.id}`, values);
    },
    onSuccess: () => {
      toast({
        title: "Resource allocation updated",
        description: "The resource allocation has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/resource-allocations`] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update resource allocation",
        description: error.message || "An error occurred while updating the resource allocation.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  async function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    
    if (allocation) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="resourceId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Resource</FormLabel>
              <Select 
                onValueChange={(value) => {
                  const resourceId = parseInt(value);
                  field.onChange(resourceId);
                  handleResourceChange(resourceId);
                }} 
                defaultValue={field.value.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select resource" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {resources?.map((resource) => (
                    <SelectItem key={resource.id} value={resource.id.toString()}>
                      {resource.name} ({resource.role})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {selectedResource && (
          <div className="rounded-md bg-muted p-3 text-sm">
            <div><strong>Hourly Rate:</strong> ${selectedResource.hourlyRate.toLocaleString()}/hour</div>
          </div>
        )}
        
        <FormField
          control={form.control}
          name="hours"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Hours</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  min="0" 
                  step="0.5" 
                  placeholder="Enter hours" 
                  {...field}
                  onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Start Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="endDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>End Date (optional)</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value || undefined}
                      onSelect={field.onChange}
                      initialFocus
                      disabled={(date) => 
                        date < (form.getValues("startDate") || new Date())
                      }
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes (optional)</FormLabel>
              <FormControl>
                <Textarea placeholder="Enter notes about this allocation" rows={3} {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {selectedResource && form.watch("hours") > 0 && (
          <div className="rounded-md bg-muted p-3 text-sm">
            <div>
              <strong>Estimated Cost:</strong> ${(selectedResource.hourlyRate * form.watch("hours")).toLocaleString()}
            </div>
          </div>
        )}
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onSuccess}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : allocation ? 'Update Allocation' : 'Allocate Resource'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
