import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { resourceFormSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

interface Resource {
  id: number;
  name: string;
  role: string;
  hourlyRate: number;
  availableHours: number;
  isActive: boolean;
}

interface ResourceFormProps {
  resource?: Resource;
  onSuccess: () => void;
}

type FormValues = z.infer<typeof resourceFormSchema>;

export default function ResourceForm({ resource, onSuccess }: ResourceFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(resourceFormSchema),
    defaultValues: {
      name: resource?.name || "",
      role: resource?.role || "",
      hourlyRate: resource?.hourlyRate || 0,
      availableHours: resource?.availableHours || 40,
      isActive: resource?.isActive ?? true,
    },
  });
  
  const createMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      return apiRequest("POST", "/api/resources", values);
    },
    onSuccess: () => {
      toast({
        title: "Resource created",
        description: "The resource has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to create resource",
        description: error.message || "An error occurred while creating the resource.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!resource) return null;
      return apiRequest("PUT", `/api/resources/${resource.id}`, values);
    },
    onSuccess: () => {
      toast({
        title: "Resource updated",
        description: "The resource has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
      onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to update resource",
        description: error.message || "An error occurred while updating the resource.",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    },
  });
  
  async function onSubmit(values: FormValues) {
    setIsSubmitting(true);
    
    if (resource) {
      updateMutation.mutate(values);
    } else {
      createMutation.mutate(values);
    }
  }
  
  // Calculate estimated weekly earnings
  const weeklyEarnings = form.watch("hourlyRate") * form.watch("availableHours");
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Resource Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter resource name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role/Position</FormLabel>
              <FormControl>
                <Input placeholder="Enter role (e.g. Financial Analyst)" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="hourlyRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Hourly Rate ($)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    step="0.01" 
                    placeholder="Enter hourly rate" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="availableHours"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Available Hours (per week)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="168" 
                    step="0.5" 
                    placeholder="Enter available hours" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        {weeklyEarnings > 0 && (
          <div className="bg-muted rounded-md p-3 text-sm">
            <div><strong>Estimated weekly earnings:</strong> ${weeklyEarnings.toLocaleString()}</div>
            <div><strong>Estimated annual earnings:</strong> ${(weeklyEarnings * 52).toLocaleString()}</div>
          </div>
        )}
        
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
              <div className="space-y-0.5">
                <FormLabel className="text-base">Active Status</FormLabel>
                <FormMessage />
                <p className="text-sm text-muted-foreground">
                  Mark this resource as available for allocation to projects
                </p>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onSuccess}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'Saving...' : resource ? 'Update Resource' : 'Create Resource'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
