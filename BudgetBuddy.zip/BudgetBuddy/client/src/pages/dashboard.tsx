import { useQuery } from "@tanstack/react-query";
import BudgetOverview from "@/components/dashboard/budget-overview";
import RecentActivity from "@/components/dashboard/recent-activity";
import ResourceUtilization from "@/components/dashboard/resource-utilization";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import ExportButton from "@/components/layout/export-button";

export default function Dashboard() {
  const { data: projects, isLoading: isLoadingProjects } = useQuery({
    queryKey: ["/api/projects"],
  });

  const { data: budgetSummary, isLoading: isLoadingBudgetSummary } = useQuery({
    queryKey: ["/api/dashboard/budget-summary"],
  });

  const { data: resourceUtilization, isLoading: isLoadingResourceUtilization } = useQuery({
    queryKey: ["/api/dashboard/resource-utilization"],
  });

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <ExportButton />
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {isLoadingBudgetSummary ? (
              <>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-[100px]" />
                    <Skeleton className="h-4 w-[70px] mt-1" />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-[100px]" />
                    <Skeleton className="h-4 w-[70px] mt-1" />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Remaining Budget</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-8 w-[100px]" />
                    <Skeleton className="h-4 w-[70px] mt-1" />
                  </CardContent>
                </Card>
              </>
            ) : (
              <>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${budgetSummary?.totalBudget.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Across all projects</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${budgetSummary?.totalExpenses.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">
                      {((budgetSummary?.totalExpenses / budgetSummary?.totalBudget) * 100 || 0).toFixed(1)}% of budget
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Remaining Budget</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${budgetSummary?.remainingBudget.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">
                      {((budgetSummary?.remainingBudget / budgetSummary?.totalBudget) * 100 || 0).toFixed(1)}% remaining
                    </p>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
          <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-1 md:col-span-2 lg:col-span-4">
              <CardHeader>
                <CardTitle>Budget Overview</CardTitle>
                <CardDescription>
                  Budget allocation and spending across all projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BudgetOverview isLoading={isLoadingProjects} projects={projects} />
              </CardContent>
            </Card>
            <Card className="col-span-1 md:col-span-2 lg:col-span-3">
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
                <CardDescription>
                  Allocation of resources across projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResourceUtilization isLoading={isLoadingResourceUtilization} utilization={resourceUtilization} />
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-4 grid-cols-1">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  Recent projects and expenses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RecentActivity isLoading={isLoadingProjects} projects={projects} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Analytics</CardTitle>
              <CardDescription>
                View detailed analytics and reports (Coming soon)
              </CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-center h-80">
              <p className="text-muted-foreground">Advanced analytics features will be available in a future update.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
