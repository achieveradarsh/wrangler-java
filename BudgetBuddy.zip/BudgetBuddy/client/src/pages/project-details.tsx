import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ChevronLeft, Clock, Calendar, DollarSign, Edit, PlusCircle, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import ProjectForm from "@/components/projects/project-form";
import ExpenseForm from "@/components/projects/expense-form";
import ResourceAllocationForm from "@/components/projects/resource-allocation-form";

interface Project {
  id: number;
  name: string;
  description: string | null;
  clientName: string;
  startDate: string;
  endDate: string | null;
  totalBudget: number;
  status: string;
}

interface Expense {
  id: number;
  projectId: number;
  categoryId: number;
  amount: number;
  description: string | null;
  date: string;
}

interface ResourceAllocation {
  id: number;
  projectId: number;
  resourceId: number;
  hours: number;
  startDate: string;
  endDate: string | null;
  notes: string | null;
}

interface Resource {
  id: number;
  name: string;
  role: string;
  hourlyRate: number;
}

interface ExpenseCategory {
  id: number;
  name: string;
}

export default function ProjectDetails() {
  const [, params] = useRoute("/projects/:id");
  const projectId = params?.id ? parseInt(params.id) : 0;
  
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [isResourceDialogOpen, setIsResourceDialogOpen] = useState(false);
  
  const { data: project, isLoading: isProjectLoading } = useQuery<Project>({
    queryKey: [`/api/projects/${projectId}`],
    enabled: !!projectId,
  });
  
  const { data: expenses, isLoading: isExpensesLoading } = useQuery<Expense[]>({
    queryKey: [`/api/projects/${projectId}/expenses`],
    enabled: !!projectId,
  });
  
  const { data: allocations, isLoading: isAllocationsLoading } = useQuery<ResourceAllocation[]>({
    queryKey: [`/api/projects/${projectId}/resource-allocations`],
    enabled: !!projectId,
  });
  
  const { data: resources } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });
  
  const { data: categories } = useQuery<ExpenseCategory[]>({
    queryKey: ["/api/expense-categories"],
  });
  
  if (isProjectLoading) {
    return (
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center gap-2 mb-4">
          <Button variant="outline" size="sm" asChild>
            <Link href="/projects">
              <ChevronLeft className="h-4 w-4 mr-1" />
              <span>Back to Projects</span>
            </Link>
          </Button>
        </div>
        <Skeleton className="h-10 w-1/3 mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-[500px]" />
      </div>
    );
  }
  
  if (!project) {
    return (
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center gap-2 mb-4">
          <Button variant="outline" size="sm" asChild>
            <Link href="/projects">
              <ChevronLeft className="h-4 w-4 mr-1" />
              <span>Back to Projects</span>
            </Link>
          </Button>
        </div>
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <h2 className="text-2xl font-bold mb-2">Project Not Found</h2>
          <p className="text-muted-foreground mb-4">The project you're looking for doesn't exist or has been deleted.</p>
          <Button asChild>
            <Link href="/projects">View All Projects</Link>
          </Button>
        </div>
      </div>
    );
  }
  
  // Calculate project metrics
  const totalExpenses = expenses?.reduce((sum, expense) => sum + expense.amount, 0) || 0;
  const remainingBudget = project.totalBudget - totalExpenses;
  const budgetUsedPercentage = Math.min((totalExpenses / project.totalBudget) * 100, 100);
  
  // Calculate resource metrics
  const totalAllocatedHours = allocations?.reduce((sum, allocation) => sum + allocation.hours, 0) || 0;
  const totalResourceCost = allocations?.reduce((sum, allocation) => {
    const resource = resources?.find(r => r.id === allocation.resourceId);
    return sum + (allocation.hours * (resource?.hourlyRate || 0));
  }, 0) || 0;
  
  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between mb-4">
        <Button variant="outline" size="sm" asChild>
          <Link href="/projects">
            <ChevronLeft className="h-4 w-4 mr-1" />
            <span>Back to Projects</span>
          </Link>
        </Button>
        <div className="flex items-center gap-2">
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-1" />
                <span>Edit Project</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Edit Project</DialogTitle>
              </DialogHeader>
              <ProjectForm project={project} onSuccess={() => setIsEditDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
          <Badge variant={
            project.status === "active" 
              ? "default"
              : project.status === "completed" 
              ? "secondary"
              : "outline"
          }>
            {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
          </Badge>
        </div>
        <p className="text-muted-foreground">Client: {project.clientName}</p>
        {project.description && <p className="mt-2">{project.description}</p>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              <Calendar className="h-4 w-4 inline mr-1" />
              Timeline
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">
              {format(new Date(project.startDate), "MMM d, yyyy")}
              {project.endDate && <span> - {format(new Date(project.endDate), "MMM d, yyyy")}</span>}
            </div>
            <p className="text-xs text-muted-foreground">
              {!project.endDate && "No end date specified"}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              <DollarSign className="h-4 w-4 inline mr-1" />
              Total Budget
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">${project.totalBudget.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Allocated funds</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              <DollarSign className="h-4 w-4 inline mr-1" />
              Expenses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">${totalExpenses.toLocaleString()}</div>
            <div className="mt-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs">{budgetUsedPercentage.toFixed(1)}% of budget</span>
                <span className="text-xs">${remainingBudget.toLocaleString()} remaining</span>
              </div>
              <Progress value={budgetUsedPercentage} className="h-2" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">
              <Clock className="h-4 w-4 inline mr-1" />
              Resource Allocation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold">{totalAllocatedHours} hours</div>
            <p className="text-xs text-muted-foreground">Est. cost: ${totalResourceCost.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="expenses" className="mt-6">
        <TabsList>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="expenses" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Expense Tracking</h2>
            <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  <span>Add Expense</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Add New Expense</DialogTitle>
                </DialogHeader>
                <ExpenseForm 
                  projectId={projectId} 
                  onSuccess={() => setIsExpenseDialogOpen(false)} 
                  categories={categories}
                />
              </DialogContent>
            </Dialog>
          </div>
          
          {isExpensesLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-12" />
              <Skeleton className="h-32" />
            </div>
          ) : expenses && expenses.length > 0 ? (
            <Card>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="py-3 px-4 text-left font-medium">Date</th>
                      <th className="py-3 px-4 text-left font-medium">Category</th>
                      <th className="py-3 px-4 text-left font-medium">Description</th>
                      <th className="py-3 px-4 text-right font-medium">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.map((expense) => {
                      const category = categories?.find(c => c.id === expense.categoryId);
                      return (
                        <tr key={expense.id} className="border-b">
                          <td className="py-3 px-4">
                            {format(new Date(expense.date), "MMM d, yyyy")}
                          </td>
                          <td className="py-3 px-4">{category?.name || "Unknown category"}</td>
                          <td className="py-3 px-4">{expense.description || "-"}</td>
                          <td className="py-3 px-4 text-right">${expense.amount.toLocaleString()}</td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted/50">
                      <td colSpan={3} className="py-3 px-4 font-medium">Total</td>
                      <td className="py-3 px-4 text-right font-medium">${totalExpenses.toLocaleString()}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          ) : (
            <div className="flex flex-col items-center justify-center border rounded-md p-8">
              <p className="text-muted-foreground mb-4">No expenses recorded for this project yet.</p>
              <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    <span>Add First Expense</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Add New Expense</DialogTitle>
                  </DialogHeader>
                  <ExpenseForm 
                    projectId={projectId} 
                    onSuccess={() => setIsExpenseDialogOpen(false)} 
                    categories={categories}
                  />
                </DialogContent>
              </Dialog>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="resources" className="space-y-4 mt-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Resource Allocation</h2>
            <Dialog open={isResourceDialogOpen} onOpenChange={setIsResourceDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  <span>Allocate Resource</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Allocate Resource</DialogTitle>
                </DialogHeader>
                <ResourceAllocationForm 
                  projectId={projectId} 
                  onSuccess={() => setIsResourceDialogOpen(false)} 
                  resources={resources}
                />
              </DialogContent>
            </Dialog>
          </div>
          
          {isAllocationsLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-12" />
              <Skeleton className="h-32" />
            </div>
          ) : allocations && allocations.length > 0 ? (
            <Card>
              <div className="rounded-md border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="py-3 px-4 text-left font-medium">Resource</th>
                      <th className="py-3 px-4 text-left font-medium">Role</th>
                      <th className="py-3 px-4 text-left font-medium">Time Period</th>
                      <th className="py-3 px-4 text-right font-medium">Hours</th>
                      <th className="py-3 px-4 text-right font-medium">Cost</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allocations.map((allocation) => {
                      const resource = resources?.find(r => r.id === allocation.resourceId);
                      const cost = (resource?.hourlyRate || 0) * allocation.hours;
                      return (
                        <tr key={allocation.id} className="border-b">
                          <td className="py-3 px-4">{resource?.name || "Unknown resource"}</td>
                          <td className="py-3 px-4">{resource?.role || "-"}</td>
                          <td className="py-3 px-4">
                            {format(new Date(allocation.startDate), "MMM d, yyyy")}
                            {allocation.endDate && 
                              <span> - {format(new Date(allocation.endDate), "MMM d, yyyy")}</span>
                            }
                          </td>
                          <td className="py-3 px-4 text-right">{allocation.hours}</td>
                          <td className="py-3 px-4 text-right">${cost.toLocaleString()}</td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted/50">
                      <td colSpan={3} className="py-3 px-4 font-medium">Total</td>
                      <td className="py-3 px-4 text-right font-medium">{totalAllocatedHours}</td>
                      <td className="py-3 px-4 text-right font-medium">${totalResourceCost.toLocaleString()}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          ) : (
            <div className="flex flex-col items-center justify-center border rounded-md p-8">
              <p className="text-muted-foreground mb-4">No resources allocated to this project yet.</p>
              <Dialog open={isResourceDialogOpen} onOpenChange={setIsResourceDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    <span>Allocate First Resource</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Allocate Resource</DialogTitle>
                  </DialogHeader>
                  <ResourceAllocationForm 
                    projectId={projectId} 
                    onSuccess={() => setIsResourceDialogOpen(false)} 
                    resources={resources}
                  />
                </DialogContent>
              </Dialog>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Financial Analytics</CardTitle>
              <CardDescription>
                Visualize your project's financial performance
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center h-[300px]">
              <PieChart className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Advanced analytics features will be available in a future update.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
