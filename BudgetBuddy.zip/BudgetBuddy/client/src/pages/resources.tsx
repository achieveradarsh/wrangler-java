import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Search, Filter, ArrowUpDown, MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ResourceForm from "@/components/resources/resource-form";
import ExportButton from "@/components/layout/export-button";

interface Resource {
  id: number;
  name: string;
  role: string;
  hourlyRate: number;
  availableHours: number;
  isActive: boolean;
}

export default function Resources() {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  
  const { data: resources, isLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });
  
  const { data: utilization } = useQuery<{
    resourceId: number;
    resourceName: string;
    allocatedHours: number;
    availableHours: number;
    utilizationPercentage: number;
  }[]>({
    queryKey: ["/api/dashboard/resource-utilization"],
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/resources/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Resource deleted",
        description: "The resource has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete resource",
        description: error.message || "An error occurred while deleting the resource.",
      });
    },
  });
  
  const handleDeleteResource = (resource: Resource) => {
    if (window.confirm(`Are you sure you want to delete the resource "${resource.name}"? This action cannot be undone.`)) {
      deleteMutation.mutate(resource.id);
    }
  };
  
  const handleEditResource = (resource: Resource) => {
    setSelectedResource(resource);
    setIsEditDialogOpen(true);
  };
  
  const filteredResources = resources?.filter(resource => 
    resource.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    resource.role.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Calculate utilization
  const getUtilizationForResource = (resourceId: number) => {
    const resourceUtilization = utilization?.find(u => u.resourceId === resourceId);
    return resourceUtilization?.utilizationPercentage || 0;
  };
  
  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Resources</h2>
        <div className="flex items-center gap-2">
          <ExportButton />
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                <span>New Resource</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create New Resource</DialogTitle>
              </DialogHeader>
              <ResourceForm onSuccess={() => setIsCreateDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search resources..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" size="sm" className="hidden md:flex items-center gap-1">
          <Filter className="h-4 w-4" />
          <span>Filter</span>
        </Button>
      </div>
      
      {isLoading ? (
        <div className="rounded-md border">
          <div className="p-4">
            <Skeleton className="h-8 w-48 mb-4" />
            <Skeleton className="h-[400px] w-full" />
          </div>
        </div>
      ) : (
        <div className="rounded-md border">
          {filteredResources && filteredResources.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[200px]">
                    <div className="flex items-center gap-1">
                      <span>Resource Name</span>
                      <ArrowUpDown className="h-3 w-3" />
                    </div>
                  </TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="hidden md:table-cell">Hourly Rate</TableHead>
                  <TableHead className="hidden md:table-cell">Available Hours</TableHead>
                  <TableHead className="hidden md:table-cell">Utilization</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredResources.map((resource) => {
                  const utilization = getUtilizationForResource(resource.id);
                  
                  return (
                    <TableRow key={resource.id}>
                      <TableCell className="font-medium">{resource.name}</TableCell>
                      <TableCell>{resource.role}</TableCell>
                      <TableCell className="hidden md:table-cell">${resource.hourlyRate.toLocaleString()}</TableCell>
                      <TableCell className="hidden md:table-cell">{resource.availableHours} hrs/week</TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div className="flex items-center">
                          <div className="w-full bg-muted rounded-full h-2.5 mr-2">
                            <div 
                              className={`h-2.5 rounded-full ${
                                utilization > 90 
                                  ? 'bg-red-500' 
                                  : utilization > 70 
                                  ? 'bg-yellow-500' 
                                  : 'bg-green-500'
                              }`} 
                              style={{ width: `${Math.min(utilization, 100)}%` }}
                            ></div>
                          </div>
                          <span>{Math.round(utilization)}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={resource.isActive ? "default" : "outline"}
                        >
                          {resource.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem 
                              className="flex items-center gap-2"
                              onClick={() => handleEditResource(resource)}
                            >
                              <Pencil className="h-4 w-4" />
                              <span>Edit</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="flex items-center gap-2 text-red-600"
                              onClick={() => handleDeleteResource(resource)}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span>Delete</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center h-60 p-4">
              <p className="text-muted-foreground mb-4">No resources found.</p>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    <span>Create your first resource</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Create New Resource</DialogTitle>
                  </DialogHeader>
                  <ResourceForm onSuccess={() => setIsCreateDialogOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      )}
      
      {/* Edit Resource Dialog */}
      {selectedResource && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Edit Resource</DialogTitle>
            </DialogHeader>
            <ResourceForm 
              resource={selectedResource} 
              onSuccess={() => {
                setIsEditDialogOpen(false);
                setSelectedResource(null);
              }} 
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
