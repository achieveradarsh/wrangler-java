import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, projectFormSchema, insertExpenseSchema, expenseFormSchema, insertResourceSchema, resourceFormSchema, insertResourceAllocationSchema, resourceAllocationFormSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper function to handle validation errors
  const validateRequest = (schema: any, data: any) => {
    try {
      return { data: schema.parse(data), error: null };
    } catch (error) {
      if (error instanceof ZodError) {
        return { data: null, error: error.format() };
      }
      return { data: null, error: "An unexpected error occurred" };
    }
  };

  // Projects API
  app.get("/api/projects", async (_req, res) => {
    try {
      const projects = await storage.getProjects();
      return res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      return res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      return res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validation = validateRequest(projectFormSchema, req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid project data", errors: validation.error });
      }

      const project = await storage.createProject(validation.data);
      return res.status(201).json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      return res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const validation = validateRequest(projectFormSchema.partial(), req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid project data", errors: validation.error });
      }

      const updatedProject = await storage.updateProject(id, validation.data);
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json(updatedProject);
    } catch (error) {
      console.error("Error updating project:", error);
      return res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const deleted = await storage.deleteProject(id);
      if (!deleted) {
        return res.status(404).json({ message: "Project not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting project:", error);
      return res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Expense Categories API
  app.get("/api/expense-categories", async (_req, res) => {
    try {
      const categories = await storage.getExpenseCategories();
      return res.json(categories);
    } catch (error) {
      console.error("Error fetching expense categories:", error);
      return res.status(500).json({ message: "Failed to fetch expense categories" });
    }
  });

  // Expenses API
  app.get("/api/expenses", async (_req, res) => {
    try {
      const expenses = await storage.getExpenses();
      return res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      return res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.get("/api/projects/:projectId/expenses", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const expenses = await storage.getExpensesByProject(projectId);
      return res.json(expenses);
    } catch (error) {
      console.error("Error fetching project expenses:", error);
      return res.status(500).json({ message: "Failed to fetch project expenses" });
    }
  });

  app.post("/api/expenses", async (req, res) => {
    try {
      const validation = validateRequest(expenseFormSchema, req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid expense data", errors: validation.error });
      }

      const expense = await storage.createExpense(validation.data);
      return res.status(201).json(expense);
    } catch (error) {
      console.error("Error creating expense:", error);
      return res.status(500).json({ message: "Failed to create expense" });
    }
  });

  app.put("/api/expenses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid expense ID" });
      }

      const validation = validateRequest(expenseFormSchema.partial(), req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid expense data", errors: validation.error });
      }

      const updatedExpense = await storage.updateExpense(id, validation.data);
      if (!updatedExpense) {
        return res.status(404).json({ message: "Expense not found" });
      }

      return res.json(updatedExpense);
    } catch (error) {
      console.error("Error updating expense:", error);
      return res.status(500).json({ message: "Failed to update expense" });
    }
  });

  app.delete("/api/expenses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid expense ID" });
      }

      const deleted = await storage.deleteExpense(id);
      if (!deleted) {
        return res.status(404).json({ message: "Expense not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting expense:", error);
      return res.status(500).json({ message: "Failed to delete expense" });
    }
  });

  // Resources API
  app.get("/api/resources", async (_req, res) => {
    try {
      const resources = await storage.getResources();
      return res.json(resources);
    } catch (error) {
      console.error("Error fetching resources:", error);
      return res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  app.post("/api/resources", async (req, res) => {
    try {
      const validation = validateRequest(resourceFormSchema, req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid resource data", errors: validation.error });
      }

      const resource = await storage.createResource(validation.data);
      return res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating resource:", error);
      return res.status(500).json({ message: "Failed to create resource" });
    }
  });

  app.put("/api/resources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const validation = validateRequest(resourceFormSchema.partial(), req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid resource data", errors: validation.error });
      }

      const updatedResource = await storage.updateResource(id, validation.data);
      if (!updatedResource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      return res.json(updatedResource);
    } catch (error) {
      console.error("Error updating resource:", error);
      return res.status(500).json({ message: "Failed to update resource" });
    }
  });

  app.delete("/api/resources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const deleted = await storage.deleteResource(id);
      if (!deleted) {
        return res.status(404).json({ message: "Resource not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting resource:", error);
      return res.status(500).json({ message: "Failed to delete resource" });
    }
  });

  // Resource Allocations API
  app.get("/api/resource-allocations", async (_req, res) => {
    try {
      const allocations = await storage.getResourceAllocations();
      return res.json(allocations);
    } catch (error) {
      console.error("Error fetching resource allocations:", error);
      return res.status(500).json({ message: "Failed to fetch resource allocations" });
    }
  });

  app.get("/api/projects/:projectId/resource-allocations", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }

      const allocations = await storage.getResourceAllocationsByProject(projectId);
      return res.json(allocations);
    } catch (error) {
      console.error("Error fetching project resource allocations:", error);
      return res.status(500).json({ message: "Failed to fetch project resource allocations" });
    }
  });

  app.post("/api/resource-allocations", async (req, res) => {
    try {
      const validation = validateRequest(resourceAllocationFormSchema, req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid resource allocation data", errors: validation.error });
      }

      const allocation = await storage.createResourceAllocation(validation.data);
      return res.status(201).json(allocation);
    } catch (error) {
      console.error("Error creating resource allocation:", error);
      return res.status(500).json({ message: "Failed to create resource allocation" });
    }
  });

  app.put("/api/resource-allocations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource allocation ID" });
      }

      const validation = validateRequest(resourceAllocationFormSchema.partial(), req.body);
      if (validation.error) {
        return res.status(400).json({ message: "Invalid resource allocation data", errors: validation.error });
      }

      const updatedAllocation = await storage.updateResourceAllocation(id, validation.data);
      if (!updatedAllocation) {
        return res.status(404).json({ message: "Resource allocation not found" });
      }

      return res.json(updatedAllocation);
    } catch (error) {
      console.error("Error updating resource allocation:", error);
      return res.status(500).json({ message: "Failed to update resource allocation" });
    }
  });

  app.delete("/api/resource-allocations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource allocation ID" });
      }

      const deleted = await storage.deleteResourceAllocation(id);
      if (!deleted) {
        return res.status(404).json({ message: "Resource allocation not found" });
      }

      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting resource allocation:", error);
      return res.status(500).json({ message: "Failed to delete resource allocation" });
    }
  });

  // Dashboard data API
  app.get("/api/dashboard/budget-summary", async (_req, res) => {
    try {
      const summary = await storage.getBudgetSummary();
      return res.json(summary);
    } catch (error) {
      console.error("Error fetching budget summary:", error);
      return res.status(500).json({ message: "Failed to fetch budget summary" });
    }
  });

  app.get("/api/dashboard/resource-utilization", async (_req, res) => {
    try {
      const utilization = await storage.getResourceUtilization();
      return res.json(utilization);
    } catch (error) {
      console.error("Error fetching resource utilization:", error);
      return res.status(500).json({ message: "Failed to fetch resource utilization" });
    }
  });

  // Data export APIs
  app.get("/api/export/projects", async (_req, res) => {
    try {
      const projects = await storage.getProjects();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=projects.json');
      return res.json(projects);
    } catch (error) {
      console.error("Error exporting projects:", error);
      return res.status(500).json({ message: "Failed to export projects" });
    }
  });

  app.get("/api/export/expenses", async (_req, res) => {
    try {
      const expenses = await storage.getExpenses();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=expenses.json');
      return res.json(expenses);
    } catch (error) {
      console.error("Error exporting expenses:", error);
      return res.status(500).json({ message: "Failed to export expenses" });
    }
  });

  app.get("/api/export/resources", async (_req, res) => {
    try {
      const resources = await storage.getResources();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=resources.json');
      return res.json(resources);
    } catch (error) {
      console.error("Error exporting resources:", error);
      return res.status(500).json({ message: "Failed to export resources" });
    }
  });

  app.get("/api/export/resource-allocations", async (_req, res) => {
    try {
      const allocations = await storage.getResourceAllocations();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=resource-allocations.json');
      return res.json(allocations);
    } catch (error) {
      console.error("Error exporting resource allocations:", error);
      return res.status(500).json({ message: "Failed to export resource allocations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
