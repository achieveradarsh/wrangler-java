import {
  users, type User, type InsertUser,
  projects, type Project, type InsertProject,
  expenseCategories, type ExpenseCategory, type InsertExpenseCategory,
  expenses, type Expense, type InsertExpense,
  resources, type Resource, type InsertResource,
  resourceAllocations, type ResourceAllocation, type InsertResourceAllocation
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project methods
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  // Expense category methods
  getExpenseCategories(): Promise<ExpenseCategory[]>;
  getExpenseCategory(id: number): Promise<ExpenseCategory | undefined>;
  createExpenseCategory(category: InsertExpenseCategory): Promise<ExpenseCategory>;
  
  // Expense methods
  getExpenses(): Promise<Expense[]>;
  getExpensesByProject(projectId: number): Promise<Expense[]>;
  getExpense(id: number): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
  
  // Resource methods
  getResources(): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  updateResource(id: number, resource: Partial<InsertResource>): Promise<Resource | undefined>;
  deleteResource(id: number): Promise<boolean>;
  
  // Resource allocation methods
  getResourceAllocations(): Promise<ResourceAllocation[]>;
  getResourceAllocationsByProject(projectId: number): Promise<ResourceAllocation[]>;
  getResourceAllocation(id: number): Promise<ResourceAllocation | undefined>;
  createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation>;
  updateResourceAllocation(id: number, allocation: Partial<InsertResourceAllocation>): Promise<ResourceAllocation | undefined>;
  deleteResourceAllocation(id: number): Promise<boolean>;
  
  // Dashboard data
  getBudgetSummary(): Promise<{
    totalBudget: number;
    totalExpenses: number;
    remainingBudget: number;
  }>;
  getResourceUtilization(): Promise<{
    resourceId: number;
    resourceName: string;
    allocatedHours: number;
    availableHours: number;
    utilizationPercentage: number;
  }[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private expenseCategories: Map<number, ExpenseCategory>;
  private expenses: Map<number, Expense>;
  private resources: Map<number, Resource>;
  private resourceAllocations: Map<number, ResourceAllocation>;
  
  private userIdCounter: number;
  private projectIdCounter: number;
  private expenseCategoryIdCounter: number;
  private expenseIdCounter: number;
  private resourceIdCounter: number;
  private resourceAllocationIdCounter: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.expenseCategories = new Map();
    this.expenses = new Map();
    this.resources = new Map();
    this.resourceAllocations = new Map();
    
    this.userIdCounter = 1;
    this.projectIdCounter = 1;
    this.expenseCategoryIdCounter = 1;
    this.expenseIdCounter = 1;
    this.resourceIdCounter = 1;
    this.resourceAllocationIdCounter = 1;
    
    // Add some default expense categories
    this.createExpenseCategory({ name: "Personnel", description: "Staff costs and contractors" });
    this.createExpenseCategory({ name: "Equipment", description: "Hardware and physical assets" });
    this.createExpenseCategory({ name: "Software", description: "Software licenses and subscriptions" });
    this.createExpenseCategory({ name: "Travel", description: "Travel and accommodation" });
    this.createExpenseCategory({ name: "Services", description: "External services and consultants" });
    this.createExpenseCategory({ name: "Other", description: "Miscellaneous expenses" });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Project methods
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }
  
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectIdCounter++;
    const newProject: Project = { ...project, id };
    this.projects.set(id, newProject);
    return newProject;
  }
  
  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const existingProject = this.projects.get(id);
    if (!existingProject) return undefined;
    
    const updatedProject = { ...existingProject, ...project };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
  
  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }
  
  // Expense category methods
  async getExpenseCategories(): Promise<ExpenseCategory[]> {
    return Array.from(this.expenseCategories.values());
  }
  
  async getExpenseCategory(id: number): Promise<ExpenseCategory | undefined> {
    return this.expenseCategories.get(id);
  }
  
  async createExpenseCategory(category: InsertExpenseCategory): Promise<ExpenseCategory> {
    const id = this.expenseCategoryIdCounter++;
    const newCategory: ExpenseCategory = { ...category, id };
    this.expenseCategories.set(id, newCategory);
    return newCategory;
  }
  
  // Expense methods
  async getExpenses(): Promise<Expense[]> {
    return Array.from(this.expenses.values());
  }
  
  async getExpensesByProject(projectId: number): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(
      (expense) => expense.projectId === projectId
    );
  }
  
  async getExpense(id: number): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }
  
  async createExpense(expense: InsertExpense): Promise<Expense> {
    const id = this.expenseIdCounter++;
    const newExpense: Expense = { ...expense, id };
    this.expenses.set(id, newExpense);
    return newExpense;
  }
  
  async updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const existingExpense = this.expenses.get(id);
    if (!existingExpense) return undefined;
    
    const updatedExpense = { ...existingExpense, ...expense };
    this.expenses.set(id, updatedExpense);
    return updatedExpense;
  }
  
  async deleteExpense(id: number): Promise<boolean> {
    return this.expenses.delete(id);
  }
  
  // Resource methods
  async getResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }
  
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }
  
  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const newResource: Resource = { ...resource, id };
    this.resources.set(id, newResource);
    return newResource;
  }
  
  async updateResource(id: number, resource: Partial<InsertResource>): Promise<Resource | undefined> {
    const existingResource = this.resources.get(id);
    if (!existingResource) return undefined;
    
    const updatedResource = { ...existingResource, ...resource };
    this.resources.set(id, updatedResource);
    return updatedResource;
  }
  
  async deleteResource(id: number): Promise<boolean> {
    return this.resources.delete(id);
  }
  
  // Resource allocation methods
  async getResourceAllocations(): Promise<ResourceAllocation[]> {
    return Array.from(this.resourceAllocations.values());
  }
  
  async getResourceAllocationsByProject(projectId: number): Promise<ResourceAllocation[]> {
    return Array.from(this.resourceAllocations.values()).filter(
      (allocation) => allocation.projectId === projectId
    );
  }
  
  async getResourceAllocation(id: number): Promise<ResourceAllocation | undefined> {
    return this.resourceAllocations.get(id);
  }
  
  async createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation> {
    const id = this.resourceAllocationIdCounter++;
    const newAllocation: ResourceAllocation = { ...allocation, id };
    this.resourceAllocations.set(id, newAllocation);
    return newAllocation;
  }
  
  async updateResourceAllocation(id: number, allocation: Partial<InsertResourceAllocation>): Promise<ResourceAllocation | undefined> {
    const existingAllocation = this.resourceAllocations.get(id);
    if (!existingAllocation) return undefined;
    
    const updatedAllocation = { ...existingAllocation, ...allocation };
    this.resourceAllocations.set(id, updatedAllocation);
    return updatedAllocation;
  }
  
  async deleteResourceAllocation(id: number): Promise<boolean> {
    return this.resourceAllocations.delete(id);
  }
  
  // Dashboard data
  async getBudgetSummary(): Promise<{
    totalBudget: number;
    totalExpenses: number;
    remainingBudget: number;
  }> {
    const projects = await this.getProjects();
    const expenses = await this.getExpenses();
    
    const totalBudget = projects.reduce((sum, project) => sum + project.totalBudget, 0);
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    return {
      totalBudget,
      totalExpenses,
      remainingBudget: totalBudget - totalExpenses
    };
  }
  
  async getResourceUtilization(): Promise<{
    resourceId: number;
    resourceName: string;
    allocatedHours: number;
    availableHours: number;
    utilizationPercentage: number;
  }[]> {
    const resources = await this.getResources();
    const allocations = await this.getResourceAllocations();
    
    return resources.map(resource => {
      const resourceAllocations = allocations.filter(
        allocation => allocation.resourceId === resource.id
      );
      
      const allocatedHours = resourceAllocations.reduce(
        (sum, allocation) => sum + allocation.hours, 0
      );
      
      const utilizationPercentage = (allocatedHours / resource.availableHours) * 100;
      
      return {
        resourceId: resource.id,
        resourceName: resource.name,
        allocatedHours,
        availableHours: resource.availableHours,
        utilizationPercentage: Math.min(utilizationPercentage, 100) // Cap at 100%
      };
    });
  }
}

export const storage = new MemStorage();
