import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("advisor"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  role: true,
});

// Project table
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  clientName: text("client_name").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  totalBudget: doublePrecision("total_budget").notNull(),
  status: text("status").notNull().default("active"), // active, completed, on-hold
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  clientName: true,
  startDate: true,
  endDate: true,
  totalBudget: true,
  status: true,
  createdBy: true,
});

// Expense categories table
export const expenseCategories = pgTable("expense_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
});

export const insertExpenseCategorySchema = createInsertSchema(expenseCategories).pick({
  name: true,
  description: true,
});

// Expenses table
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  categoryId: integer("category_id").notNull().references(() => expenseCategories.id),
  amount: doublePrecision("amount").notNull(),
  description: text("description"),
  date: timestamp("date").notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
});

export const insertExpenseSchema = createInsertSchema(expenses).pick({
  projectId: true,
  categoryId: true,
  amount: true,
  description: true,
  date: true,
  createdBy: true,
});

// Resources (staff/personnel) table
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  hourlyRate: doublePrecision("hourly_rate").notNull(),
  availableHours: doublePrecision("available_hours").notNull().default(40),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  name: true,
  role: true,
  hourlyRate: true,
  availableHours: true,
  isActive: true,
});

// Resource allocations table
export const resourceAllocations = pgTable("resource_allocations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projects.id),
  resourceId: integer("resource_id").notNull().references(() => resources.id),
  hours: doublePrecision("hours").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  notes: text("notes"),
});

export const insertResourceAllocationSchema = createInsertSchema(resourceAllocations).pick({
  projectId: true,
  resourceId: true,
  hours: true,
  startDate: true,
  endDate: true,
  notes: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type ExpenseCategory = typeof expenseCategories.$inferSelect;
export type InsertExpenseCategory = z.infer<typeof insertExpenseCategorySchema>;

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type ResourceAllocation = typeof resourceAllocations.$inferSelect;
export type InsertResourceAllocation = z.infer<typeof insertResourceAllocationSchema>;

// Extended schemas for frontend validation
export const projectFormSchema = insertProjectSchema.extend({
  startDate: z.coerce.date(),
  endDate: z.coerce.date().optional().nullable(),
  totalBudget: z.coerce.number().positive("Budget must be positive")
});

export const expenseFormSchema = insertExpenseSchema.extend({
  date: z.coerce.date(),
  amount: z.coerce.number().positive("Amount must be positive")
});

export const resourceFormSchema = insertResourceSchema.extend({
  hourlyRate: z.coerce.number().positive("Hourly rate must be positive"),
  availableHours: z.coerce.number().positive("Available hours must be positive")
});

export const resourceAllocationFormSchema = insertResourceAllocationSchema.extend({
  startDate: z.coerce.date(),
  endDate: z.coerce.date().optional().nullable(),
  hours: z.coerce.number().positive("Hours must be positive")
});
