# Wrangler

Wrangler is a data preparation tool for transforming and cleansing data. It provides a powerful yet simple way to transform raw data into structured formats suitable for analytics and machine learning.

## Enhanced Features: Byte Size and Time Duration Parsers

This fork enhances the Wrangler library with support for parsing and aggregating byte size and time duration units. These new capabilities simplify working with data that includes file sizes (KB, MB, GB) or time intervals (ms, s, m).

### Byte Size Parser

The ByteSize parser allows recognition and automatic conversion of values with byte units.

**Supported Units:**
- B (Bytes)
- KB/K (Kilobytes)
- MB/M (Megabytes)
- GB/G (Gigabytes)
- TB/T (Terabytes)
- PB/P (Petabytes)

**Examples:**
- `10KB` = 10 * 1024 bytes
- `1.5MB` = 1.5 * 1024 * 1024 bytes
- `2GB` = 2 * 1024 * 1024 * 1024 bytes

### Time Duration Parser

The TimeDuration parser allows recognition and automatic conversion of values with time units.

**Supported Units:**
- NS (Nanoseconds)
- US (Microseconds)
- MS (Milliseconds)
- S (Seconds)
- M (Minutes)
- H (Hours)
- D (Days)

**Examples:**
- `100ms` = 100 milliseconds
- `1.5s` = 1.5 seconds
- `2m` = 2 minutes

### Aggregate-Stats Directive

A new directive `aggregate-stats` has been implemented to demonstrate the usage of these parsers. It allows aggregation (sum or average) of values with byte size and time duration units.

**Usage:**
```
aggregate-stats :<size_column> :<time_column> <total_size_column> <total_time_column> [<size_output_unit>] [<time_output_unit>] [<average>]
```

**Parameters:**
- `size_column`: Source column with byte sizes
- `time_column`: Source column with time durations
- `total_size_column`: Target column for total size
- `total_time_column`: Target column for total time
- `size_output_unit`: (Optional) Output unit for size (B, KB, MB, GB, TB, PB). Default: MB
- `time_output_unit`: (Optional) Output unit for time (NS, US, MS, S, M, H, D). Default: S
- `average`: (Optional) If 'true', calculates average instead of total. Default: false

**Example Recipe:**
```
aggregate-stats :data_transfer_size :response_time total_size_mb total_time_sec 'MB' 'S' false
```

This directive processes a set of rows with `data_transfer_size` and `response_time` columns, aggregates their values, and outputs a single row with `total_size_mb` and `total_time_sec` columns containing the totals converted to MB and seconds, respectively.

**Input Example:**
- Row 1: `data_transfer_size=10KB, response_time=100ms`
- Row 2: `data_transfer_size=20KB, response_time=200ms`
- Row 3: `data_transfer_size=1.5MB, response_time=1.2s`

**Output Example:**
- `total_size_mb=1.55, total_time_sec=1.5`