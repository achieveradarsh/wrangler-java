package io.cdap.wrangler.api;

import io.cdap.wrangler.api.parser.Token;

/**
 * Interface for accessing directive arguments.
 */
public interface Arguments {
  /**
   * Checks if an argument exists.
   *
   * @param name Name of the argument.
   * @return true if argument exists, false otherwise.
   */
  boolean contains(String name);
  
  /**
   * Gets the token for an argument.
   *
   * @param name Name of the argument.
   * @return Token for the argument.
   */
  Token value(String name);
}