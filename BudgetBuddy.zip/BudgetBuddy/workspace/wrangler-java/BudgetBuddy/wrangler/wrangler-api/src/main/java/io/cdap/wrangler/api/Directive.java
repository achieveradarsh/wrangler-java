package io.cdap.wrangler.api;

import io.cdap.wrangler.api.parser.UsageDefinition;

import java.util.List;

/**
 * Defines the interface for a directive that transforms data.
 */
public interface Directive {
  /**
   * Type of plugin.
   */
  String TYPE = "directive";

  /**
   * Defines the usage and arguments for this directive.
   *
   * @return {@link UsageDefinition}
   */
  UsageDefinition define();

  /**
   * Initializes the directive with arguments.
   *
   * @param arguments Arguments passed to the directive.
   * @param context Execution context.
   * @throws DirectiveParseException If there's an error parsing the arguments.
   */
  void initialize(Arguments arguments, ExecutorContext context) throws DirectiveParseException;

  /**
   * Executes the directive on the input rows.
   *
   * @param rows List of input rows.
   * @param context Execution context.
   * @return List of transformed rows.
   * @throws DirectiveExecutionException If there's an error executing the directive.
   */
  List<Row> execute(List<Row> rows, ExecutorContext context) throws DirectiveExecutionException;

  /**
   * Destroys this directive, releasing any resources.
   */
  void destroy();
}