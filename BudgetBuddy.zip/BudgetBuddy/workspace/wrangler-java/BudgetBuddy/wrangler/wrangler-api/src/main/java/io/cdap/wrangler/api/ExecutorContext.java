package io.cdap.wrangler.api;

/**
 * Context for executing directives.
 */
public interface ExecutorContext {
  /**
   * Checks if this is the last batch of data.
   *
   * @return true if last batch, false otherwise.
   */
  boolean isLast();
  
  /**
   * Gets the name of the current stage.
   *
   * @return Name of the stage.
   */
  String getStageName();
  
  /**
   * Gets a value from the store.
   *
   * @param name Name of the value.
   * @return Value from the store.
   */
  Object getStoreGet(String name);
  
  /**
   * Puts a value in the store.
   *
   * @param name Name of the value.
   * @param value Value to store.
   */
  void putStore(String name, Object value);
}