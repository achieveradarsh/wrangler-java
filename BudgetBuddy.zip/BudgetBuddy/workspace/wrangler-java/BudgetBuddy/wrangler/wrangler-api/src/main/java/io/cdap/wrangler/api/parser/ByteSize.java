package io.cdap.wrangler.api.parser;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class represents a byte size token in the wrangler grammar.
 * It can parse strings like "10KB", "1.5MB", "2GB", etc.
 */
public class ByteSize extends Token {
  // Constants for byte size units
  private static final Map<String, Long> UNIT_MULTIPLIERS = new HashMap<>();
  static {
    // Using binary conversion (powers of 2)
    UNIT_MULTIPLIERS.put("B", 1L);
    UNIT_MULTIPLIERS.put("KB", 1024L);
    UNIT_MULTIPLIERS.put("MB", 1024L * 1024L);
    UNIT_MULTIPLIERS.put("GB", 1024L * 1024L * 1024L);
    UNIT_MULTIPLIERS.put("TB", 1024L * 1024L * 1024L * 1024L);
    UNIT_MULTIPLIERS.put("PB", 1024L * 1024L * 1024L * 1024L * 1024L);
    
    // Alternative notations
    UNIT_MULTIPLIERS.put("K", 1024L);
    UNIT_MULTIPLIERS.put("M", 1024L * 1024L);
    UNIT_MULTIPLIERS.put("G", 1024L * 1024L * 1024L);
    UNIT_MULTIPLIERS.put("T", 1024L * 1024L * 1024L * 1024L);
    UNIT_MULTIPLIERS.put("P", 1024L * 1024L * 1024L * 1024L * 1024L);
  }

  // Pattern to match byte size strings: number followed by optional unit
  private static final Pattern BYTE_SIZE_PATTERN = 
    Pattern.compile("^(\\d+(\\.\\d+)?)\\s*([KMGTP]B?|B)?$", Pattern.CASE_INSENSITIVE);

  private final String originalValue;
  private final double numericValue;
  private final String unit;
  private final long bytes;

  /**
   * Constructs a ByteSize token from a string like "10KB", "1.5MB", etc.
   *
   * @param value The string representation of a byte size.
   * @throws IllegalArgumentException If the value cannot be parsed as a byte size.
   */
  public ByteSize(String value) {
    this.originalValue = value;
    
    // Parse the value
    Matcher matcher = BYTE_SIZE_PATTERN.matcher(value.trim());
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid byte size format: " + value);
    }
    
    this.numericValue = Double.parseDouble(matcher.group(1));
    this.unit = matcher.group(3) != null ? matcher.group(3).toUpperCase() : "B";
    
    // Calculate bytes
    Long multiplier = UNIT_MULTIPLIERS.get(this.unit);
    if (multiplier == null) {
      throw new IllegalArgumentException("Unknown byte size unit: " + this.unit);
    }
    
    this.bytes = Math.round(this.numericValue * multiplier);
  }

  /**
   * @return The original string value.
   */
  public String getOriginalValue() {
    return originalValue;
  }

  /**
   * @return The numeric part of the byte size.
   */
  public double getNumericValue() {
    return numericValue;
  }

  /**
   * @return The unit part of the byte size (e.g., "KB", "MB").
   */
  public String getUnit() {
    return unit;
  }

  /**
   * @return The byte size value converted to bytes.
   */
  public long getBytes() {
    return bytes;
  }

  /**
   * Converts the byte size to a specific unit.
   *
   * @param targetUnit The target unit (e.g., "KB", "MB").
   * @return The value in the target unit.
   * @throws IllegalArgumentException If the target unit is invalid.
   */
  public double to(String targetUnit) {
    if (!UNIT_MULTIPLIERS.containsKey(targetUnit.toUpperCase())) {
      throw new IllegalArgumentException("Unknown target unit: " + targetUnit);
    }
    
    long targetMultiplier = UNIT_MULTIPLIERS.get(targetUnit.toUpperCase());
    return (double) bytes / targetMultiplier;
  }

  /**
   * @return The value of this token as a Long representing bytes.
   */
  @Override
  public Object value() {
    return bytes;
  }

  /**
   * @return A string representation of this byte size.
   */
  @Override
  public String toString() {
    return originalValue;
  }
}