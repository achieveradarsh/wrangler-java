package io.cdap.wrangler.api.parser;

/**
 * A token representing a column name.
 */
public class ColumnName extends Token {
  private final String name;

  /**
   * Constructor for ColumnName.
   *
   * @param name Name of the column.
   */
  public ColumnName(String name) {
    if (name == null || name.isEmpty()) {
      throw new IllegalArgumentException("Column name cannot be null or empty");
    }
    
    // If the name starts with a colon, remove it
    if (name.startsWith(":")) {
      this.name = name.substring(1);
    } else {
      this.name = name;
    }
  }

  /**
   * @return The column name.
   */
  public String value() {
    return name;
  }

  /**
   * @return String representation of the column name.
   */
  @Override
  public String toString() {
    return ":" + name;
  }
}