package io.cdap.wrangler.api.parser;

/**
 * A token representing text or string values.
 */
public class Text extends Token {
  private final String text;

  /**
   * Constructor for Text.
   *
   * @param text The string value.
   */
  public Text(String text) {
    this.text = text;
  }

  /**
   * @return The string value.
   */
  @Override
  public String value() {
    return text;
  }

  /**
   * @return String representation of the text.
   */
  @Override
  public String toString() {
    return "'" + text + "'";
  }
}