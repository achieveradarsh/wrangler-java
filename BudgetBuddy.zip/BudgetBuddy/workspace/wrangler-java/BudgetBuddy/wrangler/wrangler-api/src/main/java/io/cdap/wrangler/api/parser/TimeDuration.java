package io.cdap.wrangler.api.parser;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class represents a time duration token in the wrangler grammar.
 * It can parse strings like "10ms", "1.5s", "2m", etc.
 */
public class TimeDuration extends Token {
  // Constants for time units (in nanoseconds)
  private static final Map<String, Long> UNIT_MULTIPLIERS = new HashMap<>();
  static {
    UNIT_MULTIPLIERS.put("NS", 1L);
    UNIT_MULTIPLIERS.put("US", TimeUnit.MICROSECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("MS", TimeUnit.MILLISECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("S", TimeUnit.SECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("M", TimeUnit.MINUTES.toNanos(1));
    UNIT_MULTIPLIERS.put("H", TimeUnit.HOURS.toNanos(1));
    UNIT_MULTIPLIERS.put("D", TimeUnit.DAYS.toNanos(1));
    
    // Full names
    UNIT_MULTIPLIERS.put("NANOSECOND", 1L);
    UNIT_MULTIPLIERS.put("NANOSECONDS", 1L);
    UNIT_MULTIPLIERS.put("MICROSECOND", TimeUnit.MICROSECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("MICROSECONDS", TimeUnit.MICROSECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("MILLISECOND", TimeUnit.MILLISECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("MILLISECONDS", TimeUnit.MILLISECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("SECOND", TimeUnit.SECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("SECONDS", TimeUnit.SECONDS.toNanos(1));
    UNIT_MULTIPLIERS.put("MINUTE", TimeUnit.MINUTES.toNanos(1));
    UNIT_MULTIPLIERS.put("MINUTES", TimeUnit.MINUTES.toNanos(1));
    UNIT_MULTIPLIERS.put("HOUR", TimeUnit.HOURS.toNanos(1));
    UNIT_MULTIPLIERS.put("HOURS", TimeUnit.HOURS.toNanos(1));
    UNIT_MULTIPLIERS.put("DAY", TimeUnit.DAYS.toNanos(1));
    UNIT_MULTIPLIERS.put("DAYS", TimeUnit.DAYS.toNanos(1));
  }

  // Pattern to match time duration strings: number followed by optional unit
  private static final Pattern TIME_DURATION_PATTERN = 
    Pattern.compile("^(\\d+(\\.\\d+)?)\\s*([a-zA-Z]+)?$");

  private final String originalValue;
  private final double numericValue;
  private final String unit;
  private final long nanoseconds;

  /**
   * Constructs a TimeDuration token from a string like "10ms", "1.5s", etc.
   *
   * @param value The string representation of a time duration.
   * @throws IllegalArgumentException If the value cannot be parsed as a time duration.
   */
  public TimeDuration(String value) {
    this.originalValue = value;
    
    // Parse the value
    Matcher matcher = TIME_DURATION_PATTERN.matcher(value.trim());
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid time duration format: " + value);
    }
    
    this.numericValue = Double.parseDouble(matcher.group(1));
    String unitPart = matcher.group(3);
    this.unit = unitPart != null ? unitPart.toUpperCase() : "MS"; // Default to milliseconds if no unit provided
    
    // Calculate nanoseconds
    Long multiplier = UNIT_MULTIPLIERS.get(this.unit);
    if (multiplier == null) {
      throw new IllegalArgumentException("Unknown time unit: " + this.unit);
    }
    
    this.nanoseconds = Math.round(this.numericValue * multiplier);
  }

  /**
   * @return The original string value.
   */
  public String getOriginalValue() {
    return originalValue;
  }

  /**
   * @return The numeric part of the time duration.
   */
  public double getNumericValue() {
    return numericValue;
  }

  /**
   * @return The unit part of the time duration (e.g., "MS", "S").
   */
  public String getUnit() {
    return unit;
  }

  /**
   * @return The time duration value converted to nanoseconds.
   */
  public long getNanoseconds() {
    return nanoseconds;
  }

  /**
   * @return The time duration value converted to milliseconds.
   */
  public long getMilliseconds() {
    return TimeUnit.NANOSECONDS.toMillis(nanoseconds);
  }

  /**
   * @return The time duration value converted to seconds.
   */
  public double getSeconds() {
    return nanoseconds / (double) TimeUnit.SECONDS.toNanos(1);
  }

  /**
   * Converts the time duration to a specific unit.
   *
   * @param targetUnit The target unit (e.g., "MS", "S").
   * @return The value in the target unit.
   * @throws IllegalArgumentException If the target unit is invalid.
   */
  public double to(String targetUnit) {
    if (!UNIT_MULTIPLIERS.containsKey(targetUnit.toUpperCase())) {
      throw new IllegalArgumentException("Unknown target unit: " + targetUnit);
    }
    
    long targetMultiplier = UNIT_MULTIPLIERS.get(targetUnit.toUpperCase());
    return (double) nanoseconds / targetMultiplier;
  }

  /**
   * @return The value of this token as a Long representing nanoseconds.
   */
  @Override
  public Object value() {
    return nanoseconds;
  }

  /**
   * @return A string representation of this time duration.
   */
  @Override
  public String toString() {
    return originalValue;
  }
}