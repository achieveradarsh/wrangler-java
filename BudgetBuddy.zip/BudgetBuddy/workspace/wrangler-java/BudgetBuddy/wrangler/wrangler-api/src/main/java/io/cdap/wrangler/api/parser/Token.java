package io.cdap.wrangler.api.parser;

/**
 * Represents a token in the wrangler grammar.
 * This is an abstract class that all token types must extend.
 */
public abstract class Token {
  /**
   * Returns the value of this token.
   *
   * @return Value of the token.
   */
  public abstract Object value();
}