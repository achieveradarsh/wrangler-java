package io.cdap.wrangler.api.parser;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A group of tokens from the parser.
 */
public class TokenGroup implements Iterable<Token> {
  private final List<Token> tokens;

  /**
   * Constructor for TokenGroup.
   */
  public TokenGroup() {
    tokens = new ArrayList<>();
  }

  /**
   * Add a token to the group.
   *
   * @param token Token to be added to the group.
   */
  public void add(Token token) {
    tokens.add(token);
  }

  /**
   * Returns the size of tokens in the group.
   *
   * @return Number of tokens in the group.
   */
  public int size() {
    return tokens.size();
  }

  /**
   * Returns the token at a given index.
   *
   * @param idx Index of the token to be returned.
   * @return Token at the given index.
   */
  public Token get(int idx) {
    return tokens.get(idx);
  }

  /**
   * Returns an iterator over the tokens.
   *
   * @return Iterator over tokens.
   */
  @Override
  public Iterator<Token> iterator() {
    return tokens.iterator();
  }
}