package io.cdap.wrangler.api.parser;

/**
 * Enumeration of token types in the wrangler grammar.
 */
public enum TokenType {
  NUMERIC,
  STRING,
  BOOLEAN,
  COLUMN_NAME,
  COLUMN_NUMBER,
  DIRECTIVE_NAME,
  MACRO,
  PROPERTY,
  EXPRESSION,
  BYTE_SIZE,      // Added for byte size support
  TIME_DURATION,  // Added for time duration support
  // Add other token types as needed
}