package io.cdap.wrangler.api.parser;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Defines the usage for a directive, including its arguments.
 */
public class UsageDefinition {
  private final String name;
  private final Map<String, ArgumentDefinition> arguments;

  /**
   * Constructor for UsageDefinition.
   *
   * @param name The name of the directive.
   * @param arguments The map of argument definitions.
   */
  private UsageDefinition(String name, Map<String, ArgumentDefinition> arguments) {
    this.name = name;
    this.arguments = arguments;
  }

  /**
   * @return The name of the directive.
   */
  public String getName() {
    return name;
  }

  /**
   * @return The map of argument definitions.
   */
  public Map<String, ArgumentDefinition> getArguments() {
    return arguments;
  }

  /**
   * Create a builder for UsageDefinition.
   *
   * @param name The name of the directive.
   * @return A builder instance.
   */
  public static Builder builder(String name) {
    return new Builder(name);
  }

  /**
   * Builder for UsageDefinition.
   */
  public static class Builder {
    private final String name;
    private final Map<String, ArgumentDefinition> arguments;

    /**
     * Constructor for Builder.
     *
     * @param name The name of the directive.
     */
    public Builder(String name) {
      this.name = name;
      this.arguments = new LinkedHashMap<>();
    }

    /**
     * Define a required argument.
     *
     * @param name The name of the argument.
     * @param type The type of the argument.
     * @return The builder instance.
     */
    public Builder define(String name, TokenType type) {
      arguments.put(name, new ArgumentDefinition(name, type, null, true));
      return this;
    }

    /**
     * Define an optional argument with a default value.
     *
     * @param name The name of the argument.
     * @param type The type of the argument.
     * @param defaultValue The default value for the argument.
     * @return The builder instance.
     */
    public Builder define(String name, TokenType type, String defaultValue) {
      arguments.put(name, new ArgumentDefinition(name, type, defaultValue, false));
      return this;
    }

    /**
     * Build the UsageDefinition.
     *
     * @return The built UsageDefinition.
     */
    public UsageDefinition build() {
      return new UsageDefinition(name, arguments);
    }
  }

  /**
   * Defines an argument for a directive.
   */
  public static class ArgumentDefinition {
    private final String name;
    private final TokenType type;
    private final String defaultValue;
    private final boolean required;

    /**
     * Constructor for ArgumentDefinition.
     *
     * @param name The name of the argument.
     * @param type The type of the argument.
     * @param defaultValue The default value for the argument.
     * @param required Whether the argument is required.
     */
    public ArgumentDefinition(String name, TokenType type, String defaultValue, boolean required) {
      this.name = name;
      this.type = type;
      this.defaultValue = defaultValue;
      this.required = required;
    }

    /**
     * @return The name of the argument.
     */
    public String getName() {
      return name;
    }

    /**
     * @return The type of the argument.
     */
    public TokenType getType() {
      return type;
    }

    /**
     * @return The default value for the argument.
     */
    public String getDefaultValue() {
      return defaultValue;
    }

    /**
     * @return Whether the argument is required.
     */
    public boolean isRequired() {
      return required;
    }
  }
}