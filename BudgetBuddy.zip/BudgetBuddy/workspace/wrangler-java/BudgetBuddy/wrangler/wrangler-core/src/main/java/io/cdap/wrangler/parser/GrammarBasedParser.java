package io.cdap.wrangler.parser;

import io.cdap.wrangler.api.parser.ByteSize;
import io.cdap.wrangler.api.parser.TimeDuration;
import io.cdap.wrangler.api.parser.Token;
import io.cdap.wrangler.api.parser.TokenGroup;
import org.antlr.v4.runtime.tree.ParseTree;

/**
 * The GrammarBasedParser class extends DirectivesBaseVisitor to handle the parsing of directives
 * and their arguments.
 */
public class GrammarBasedParser extends DirectivesBaseVisitor<TokenGroup> {

  /**
   * Visit a parse tree produced by {@link DirectivesParser#byteSizeArg}.
   *
   * @param ctx the parse tree
   * @return the token group for byte size
   */
  @Override
  public TokenGroup visitByteSizeArg(DirectivesParser.ByteSizeArgContext ctx) {
    TokenGroup tokenGroup = new TokenGroup();
    String text = ctx.getText();
    Token token = new ByteSize(text);
    tokenGroup.add(token);
    return tokenGroup;
  }

  /**
   * Visit a parse tree produced by {@link DirectivesParser#timeDurationArg}.
   *
   * @param ctx the parse tree
   * @return the token group for time duration
   */
  @Override
  public TokenGroup visitTimeDurationArg(DirectivesParser.TimeDurationArgContext ctx) {
    TokenGroup tokenGroup = new TokenGroup();
    String text = ctx.getText();
    Token token = new TimeDuration(text);
    tokenGroup.add(token);
    return tokenGroup;
  }

  // Add implementations for other visit methods (columnArg, stringArg, etc.)
  // that would be in the complete implementation
}