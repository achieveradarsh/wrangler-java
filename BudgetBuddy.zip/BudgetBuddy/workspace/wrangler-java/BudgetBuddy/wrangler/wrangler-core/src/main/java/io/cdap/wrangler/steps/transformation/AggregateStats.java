package io.cdap.wrangler.steps.transformation;

import io.cdap.cdap.api.annotation.Description;
import io.cdap.cdap.api.annotation.Name;
import io.cdap.cdap.api.annotation.Plugin;
import io.cdap.wrangler.api.Arguments;
import io.cdap.wrangler.api.Directive;
import io.cdap.wrangler.api.DirectiveExecutionException;
import io.cdap.wrangler.api.DirectiveParseException;
import io.cdap.wrangler.api.ExecutorContext;
import io.cdap.wrangler.api.Row;
import io.cdap.wrangler.api.annotations.Categories;
import io.cdap.wrangler.api.parser.ByteSize;
import io.cdap.wrangler.api.parser.ColumnName;
import io.cdap.wrangler.api.parser.Text;
import io.cdap.wrangler.api.parser.TimeDuration;
import io.cdap.wrangler.api.parser.TokenType;
import io.cdap.wrangler.api.parser.UsageDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Directive for aggregating byte size and time duration statistics.
 */
@Plugin(type = Directive.TYPE)
@Name("aggregate-stats")
@Categories(categories = { "transform", "aggregator" })
@Description("Aggregates byte size and time duration statistics from columns.")
public class AggregateStats implements Directive {

  public static final String NAME = "aggregate-stats";
  private String sizeColumn;
  private String timeColumn;
  private String totalSizeColumn;
  private String totalTimeColumn;
  private String sizeOutputUnit;
  private String timeOutputUnit;
  private boolean average;

  // Store for aggregation
  private long totalBytes = 0;
  private long totalNanoseconds = 0;
  private int rowCount = 0;
  private boolean finalized = false;

  /**
   * Defines the usage and arguments for the aggregate-stats directive.
   *
   * @return {@link UsageDefinition}
   */
  @Override
  public UsageDefinition define() {
    UsageDefinition.Builder builder = UsageDefinition.builder(NAME);
    builder.define("sizeColumn", TokenType.COLUMN_NAME);
    builder.define("timeColumn", TokenType.COLUMN_NAME);
    builder.define("totalSizeColumn", TokenType.COLUMN_NAME);
    builder.define("totalTimeColumn", TokenType.COLUMN_NAME);
    builder.define("sizeOutputUnit", TokenType.STRING, "MB");  // Default to MB
    builder.define("timeOutputUnit", TokenType.STRING, "s");   // Default to seconds
    builder.define("average", TokenType.BOOLEAN, "false");     // Default to total (not average)
    
    return builder.build();
  }

  /**
   * Initializes the directive with arguments.
   *
   * @param arguments Arguments passed to the directive.
   * @param context Execution context.
   */
  @Override
  public void initialize(Arguments arguments, ExecutorContext context) throws DirectiveParseException {
    this.sizeColumn = ((ColumnName) arguments.value("sizeColumn")).value();
    this.timeColumn = ((ColumnName) arguments.value("timeColumn")).value();
    this.totalSizeColumn = ((ColumnName) arguments.value("totalSizeColumn")).value();
    this.totalTimeColumn = ((ColumnName) arguments.value("totalTimeColumn")).value();
    
    if (arguments.contains("sizeOutputUnit")) {
      this.sizeOutputUnit = ((Text) arguments.value("sizeOutputUnit")).value().toUpperCase();
    } else {
      this.sizeOutputUnit = "MB";
    }
    
    if (arguments.contains("timeOutputUnit")) {
      this.timeOutputUnit = ((Text) arguments.value("timeOutputUnit")).value().toUpperCase();
    } else {
      this.timeOutputUnit = "S";
    }
    
    if (arguments.contains("average")) {
      this.average = (Boolean) arguments.value("average").value();
    } else {
      this.average = false;
    }

    // Reset aggregation store
    this.totalBytes = 0;
    this.totalNanoseconds = 0;
    this.rowCount = 0;
    this.finalized = false;
  }

  /**
   * Executes the directive on the input row.
   *
   * @param rows List of input rows.
   * @param context Execution context.
   * @return List of transformed rows.
   */
  @Override
  public List<Row> execute(List<Row> rows, ExecutorContext context) throws DirectiveExecutionException {
    // If already finalized, return the aggregated result
    if (finalized) {
      return rows;
    }

    // This is the last batch, so finalize the aggregation
    if (context.isLast()) {
      return finalizeAggregation(rows);
    }

    // Process each row for aggregation
    for (Row row : rows) {
      try {
        // Process byte size
        if (row.has(sizeColumn)) {
          Object sizeObj = row.getValue(sizeColumn);
          long bytes = 0;
          
          // Handle different input types
          if (sizeObj instanceof ByteSize) {
            bytes = ((ByteSize) sizeObj).getBytes();
          } else if (sizeObj instanceof String) {
            try {
              bytes = new ByteSize((String) sizeObj).getBytes();
            } catch (IllegalArgumentException e) {
              // Skip row if parsing fails
              continue;
            }
          } else if (sizeObj instanceof Number) {
            // Assume raw bytes if number
            bytes = ((Number) sizeObj).longValue();
          }
          
          totalBytes += bytes;
        }
        
        // Process time duration
        if (row.has(timeColumn)) {
          Object timeObj = row.getValue(timeColumn);
          long nanos = 0;
          
          // Handle different input types
          if (timeObj instanceof TimeDuration) {
            nanos = ((TimeDuration) timeObj).getNanoseconds();
          } else if (timeObj instanceof String) {
            try {
              nanos = new TimeDuration((String) timeObj).getNanoseconds();
            } catch (IllegalArgumentException e) {
              // Continue with next row if parsing fails
              continue;
            }
          } else if (timeObj instanceof Number) {
            // Assume milliseconds if raw number
            nanos = TimeUnit.MILLISECONDS.toNanos(((Number) timeObj).longValue());
          }
          
          totalNanoseconds += nanos;
        }
        
        rowCount++;
      } catch (Exception e) {
        // Skip rows with errors
      }
    }
    
    // Return empty result for intermediate processing
    return rows;
  }

  /**
   * Finalizes the aggregation and returns the result row.
   *
   * @param rows Current batch of rows.
   * @return List containing a single row with aggregation results.
   */
  private List<Row> finalizeAggregation(List<Row> rows) {
    // Process the last batch
    rows = execute(rows, null);
    
    // Create result row
    Row resultRow = new Row();
    
    // Calculate final values
    double finalSizeValue;
    double finalTimeValue;
    
    if (average && rowCount > 0) {
      // Calculate averages
      finalSizeValue = convertBytes(totalBytes / (double) rowCount, sizeOutputUnit);
      finalTimeValue = convertNanos(totalNanoseconds / (double) rowCount, timeOutputUnit);
    } else {
      // Calculate totals
      finalSizeValue = convertBytes(totalBytes, sizeOutputUnit);
      finalTimeValue = convertNanos(totalNanoseconds, timeOutputUnit);
    }
    
    // Add results to the row
    resultRow.add(totalSizeColumn, finalSizeValue);
    resultRow.add(totalTimeColumn, finalTimeValue);
    
    // Mark as finalized to prevent re-execution
    finalized = true;
    
    // Return the result row
    rows.clear();
    rows.add(resultRow);
    return rows;
  }

  /**
   * Converts bytes to the specified output unit.
   *
   * @param bytes Bytes to convert.
   * @param unit Target unit (B, KB, MB, GB, TB, PB).
   * @return Converted value.
   */
  private double convertBytes(double bytes, String unit) {
    switch (unit) {
      case "B":
        return bytes;
      case "KB":
        return bytes / 1024.0;
      case "MB":
        return bytes / (1024.0 * 1024.0);
      case "GB":
        return bytes / (1024.0 * 1024.0 * 1024.0);
      case "TB":
        return bytes / (1024.0 * 1024.0 * 1024.0 * 1024.0);
      case "PB":
        return bytes / (1024.0 * 1024.0 * 1024.0 * 1024.0 * 1024.0);
      default:
        return bytes / (1024.0 * 1024.0); // Default to MB
    }
  }

  /**
   * Converts nanoseconds to the specified output unit.
   *
   * @param nanos Nanoseconds to convert.
   * @param unit Target unit (NS, US, MS, S, M, H, D).
   * @return Converted value.
   */
  private double convertNanos(double nanos, String unit) {
    switch (unit) {
      case "NS":
        return nanos;
      case "US":
        return nanos / 1000.0;
      case "MS":
        return nanos / 1000000.0;
      case "S":
        return nanos / 1000000000.0;
      case "M":
        return nanos / (60.0 * 1000000000.0);
      case "H":
        return nanos / (60.0 * 60.0 * 1000000000.0);
      case "D":
        return nanos / (24.0 * 60.0 * 60.0 * 1000000000.0);
      default:
        return nanos / 1000000000.0; // Default to seconds
    }
  }

  /**
   * Destroys this directive.
   */
  @Override
  public void destroy() {
    // No resources to clean up
  }
}