package io.cdap.wrangler.api.parser;

import org.junit.Assert;
import org.junit.Test;

/**
 * Tests for {@link ByteSize} class.
 */
public class ByteSizeTest {

  @Test
  public void testValidByteSizeParsing() {
    // Test basic units
    ByteSize bytes = new ByteSize("1024B");
    Assert.assertEquals(1024L, bytes.getBytes());
    
    ByteSize kilobytes = new ByteSize("1KB");
    Assert.assertEquals(1024L, kilobytes.getBytes());
    
    ByteSize megabytes = new ByteSize("1MB");
    Assert.assertEquals(1024L * 1024L, megabytes.getBytes());
    
    ByteSize gigabytes = new ByteSize("1GB");
    Assert.assertEquals(1024L * 1024L * 1024L, gigabytes.getBytes());
    
    ByteSize terabytes = new ByteSize("1TB");
    Assert.assertEquals(1024L * 1024L * 1024L * 1024L, terabytes.getBytes());
    
    // Test decimal values
    ByteSize decimalKB = new ByteSize("1.5KB");
    Assert.assertEquals(1536L, decimalKB.getBytes());
    
    // Test alternative notations
    ByteSize kilo = new ByteSize("1K");
    Assert.assertEquals(1024L, kilo.getBytes());
    
    ByteSize mega = new ByteSize("1M");
    Assert.assertEquals(1024L * 1024L, mega.getBytes());
    
    // Test with spaces
    ByteSize withSpace = new ByteSize("2 MB");
    Assert.assertEquals(2L * 1024L * 1024L, withSpace.getBytes());
    
    // Test case insensitivity
    ByteSize mixedCase = new ByteSize("1Kb");
    Assert.assertEquals(1024L, mixedCase.getBytes());
  }
  
  @Test
  public void testByteSizeConversion() {
    ByteSize size = new ByteSize("1024KB");
    
    Assert.assertEquals(1024.0 * 1024.0, size.getBytes(), 0.001);
    Assert.assertEquals(1024.0, size.to("KB"), 0.001);
    Assert.assertEquals(1.0, size.to("MB"), 0.001);
    Assert.assertEquals(0.001, size.to("GB"), 0.0001);
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidFormat() {
    // Should throw IllegalArgumentException for invalid format
    new ByteSize("not-a-size");
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidUnit() {
    // Should throw IllegalArgumentException for invalid unit
    new ByteSize("1XB");
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidConversionUnit() {
    ByteSize size = new ByteSize("1MB");
    // Should throw IllegalArgumentException for invalid conversion unit
    size.to("XB");
  }

  @Test
  public void testValue() {
    ByteSize size = new ByteSize("1MB");
    Assert.assertEquals(1024L * 1024L, size.value());
  }
  
  @Test
  public void testToString() {
    String sizeString = "1.5GB";
    ByteSize size = new ByteSize(sizeString);
    Assert.assertEquals(sizeString, size.toString());
  }
}