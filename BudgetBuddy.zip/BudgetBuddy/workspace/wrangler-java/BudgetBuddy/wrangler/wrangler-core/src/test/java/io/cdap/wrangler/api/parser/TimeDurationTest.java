package io.cdap.wrangler.api.parser;

import org.junit.Assert;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

/**
 * Tests for {@link TimeDuration} class.
 */
public class TimeDurationTest {

  @Test
  public void testValidTimeDurationParsing() {
    // Test basic units
    TimeDuration nanos = new TimeDuration("1000NS");
    Assert.assertEquals(1000L, nanos.getNanoseconds());
    
    TimeDuration micros = new TimeDuration("1US");
    Assert.assertEquals(TimeUnit.MICROSECONDS.toNanos(1), micros.getNanoseconds());
    
    TimeDuration millis = new TimeDuration("1MS");
    Assert.assertEquals(TimeUnit.MILLISECONDS.toNanos(1), millis.getNanoseconds());
    
    TimeDuration seconds = new TimeDuration("1S");
    Assert.assertEquals(TimeUnit.SECONDS.toNanos(1), seconds.getNanoseconds());
    
    TimeDuration minutes = new TimeDuration("1M");
    Assert.assertEquals(TimeUnit.MINUTES.toNanos(1), minutes.getNanoseconds());
    
    TimeDuration hours = new TimeDuration("1H");
    Assert.assertEquals(TimeUnit.HOURS.toNanos(1), hours.getNanoseconds());
    
    TimeDuration days = new TimeDuration("1D");
    Assert.assertEquals(TimeUnit.DAYS.toNanos(1), days.getNanoseconds());
    
    // Test decimal values
    TimeDuration decimalMS = new TimeDuration("1.5MS");
    Assert.assertEquals(1500000L, decimalMS.getNanoseconds());
    
    // Test full unit names
    TimeDuration fullNameMillis = new TimeDuration("1MILLISECOND");
    Assert.assertEquals(TimeUnit.MILLISECONDS.toNanos(1), fullNameMillis.getNanoseconds());
    
    TimeDuration fullNameSeconds = new TimeDuration("1SECONDS");
    Assert.assertEquals(TimeUnit.SECONDS.toNanos(1), fullNameSeconds.getNanoseconds());
    
    // Test with spaces
    TimeDuration withSpace = new TimeDuration("2 MS");
    Assert.assertEquals(TimeUnit.MILLISECONDS.toNanos(2), withSpace.getNanoseconds());
    
    // Test case insensitivity
    TimeDuration mixedCase = new TimeDuration("1Ms");
    Assert.assertEquals(TimeUnit.MILLISECONDS.toNanos(1), mixedCase.getNanoseconds());
    
    // Test default unit (MS)
    TimeDuration defaultUnit = new TimeDuration("100");
    Assert.assertEquals(TimeUnit.MILLISECONDS.toNanos(100), defaultUnit.getNanoseconds());
  }
  
  @Test
  public void testTimeDurationConversion() {
    TimeDuration duration = new TimeDuration("1000MS");
    
    Assert.assertEquals(1000 * 1000000L, duration.getNanoseconds());
    Assert.assertEquals(1000L, duration.getMilliseconds());
    Assert.assertEquals(1.0, duration.getSeconds(), 0.001);
    
    Assert.assertEquals(1000000000.0, duration.to("NS"), 0.001);
    Assert.assertEquals(1000000.0, duration.to("US"), 0.001);
    Assert.assertEquals(1000.0, duration.to("MS"), 0.001);
    Assert.assertEquals(1.0, duration.to("S"), 0.001);
    Assert.assertEquals(1.0 / 60.0, duration.to("M"), 0.0001);
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidFormat() {
    // Should throw IllegalArgumentException for invalid format
    new TimeDuration("not-a-duration");
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidUnit() {
    // Should throw IllegalArgumentException for invalid unit
    new TimeDuration("1XS");
  }
  
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidConversionUnit() {
    TimeDuration duration = new TimeDuration("1S");
    // Should throw IllegalArgumentException for invalid conversion unit
    duration.to("XS");
  }

  @Test
  public void testValue() {
    TimeDuration duration = new TimeDuration("1S");
    Assert.assertEquals(TimeUnit.SECONDS.toNanos(1), duration.value());
  }
  
  @Test
  public void testToString() {
    String durationString = "1.5S";
    TimeDuration duration = new TimeDuration(durationString);
    Assert.assertEquals(durationString, duration.toString());
  }
}