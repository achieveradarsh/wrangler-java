package io.cdap.wrangler.parser;

import io.cdap.wrangler.api.parser.ByteSize;
import io.cdap.wrangler.api.parser.TimeDuration;
import io.cdap.wrangler.api.parser.Token;
import io.cdap.wrangler.api.parser.TokenGroup;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.Assert;
import org.junit.Test;

/**
 * Tests for {@link GrammarBasedParser} with the new ByteSize and TimeDuration tokens.
 */
public class GrammarBasedParserTest {

  /**
   * Helper method to parse a single argument.
   *
   * @param input The input string.
   * @return The parsed TokenGroup.
   */
  private TokenGroup parseArg(String input) {
    try {
      ANTLRInputStream stream = new ANTLRInputStream(input);
      DirectivesLexer lexer = new DirectivesLexer(stream);
      CommonTokenStream tokenStream = new CommonTokenStream(lexer);
      DirectivesParser parser = new DirectivesParser(tokenStream);
      GrammarBasedParser visitor = new GrammarBasedParser();

      // Parse the appropriate rule based on the token type
      if (input.matches(".*[kKmMgGtTpP][bB]?")) {
        ParseTree tree = parser.byteSizeArg();
        return visitor.visitByteSizeArg((DirectivesParser.ByteSizeArgContext) tree);
      } else if (input.matches(".*[nNuUmMsShHdD][sS]?") || 
                input.matches(".*(?:nanosecond|microsecond|millisecond|second|minute|hour|day)s?")) {
        ParseTree tree = parser.timeDurationArg();
        return visitor.visitTimeDurationArg((DirectivesParser.TimeDurationArgContext) tree);
      }
      
      return null;
    } catch (Exception e) {
      Assert.fail("Failed to parse input: " + input + ", error: " + e.getMessage());
      return null;
    }
  }

  @Test
  public void testByteSizeParsing() {
    // Test basic byte size parsing
    TokenGroup group = parseArg("10KB");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    Token token = group.get(0);
    Assert.assertTrue(token instanceof ByteSize);
    Assert.assertEquals(10 * 1024L, token.value());

    // Test decimal byte size
    group = parseArg("1.5MB");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    token = group.get(0);
    Assert.assertTrue(token instanceof ByteSize);
    Assert.assertEquals((long)(1.5 * 1024 * 1024), token.value());
    
    // Test gigabytes
    group = parseArg("2GB");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    token = group.get(0);
    Assert.assertTrue(token instanceof ByteSize);
    Assert.assertEquals(2L * 1024 * 1024 * 1024, token.value());
  }

  @Test
  public void testTimeDurationParsing() {
    // Test basic time duration parsing (milliseconds)
    TokenGroup group = parseArg("100MS");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    Token token = group.get(0);
    Assert.assertTrue(token instanceof TimeDuration);
    Assert.assertEquals(100 * 1000000L, token.value());

    // Test seconds
    group = parseArg("1.5S");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    token = group.get(0);
    Assert.assertTrue(token instanceof TimeDuration);
    TimeDuration duration = (TimeDuration) token;
    Assert.assertEquals(1.5, duration.getSeconds(), 0.001);
    
    // Test minutes
    group = parseArg("2M");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    token = group.get(0);
    Assert.assertTrue(token instanceof TimeDuration);
    duration = (TimeDuration) token;
    Assert.assertEquals(2 * 60, duration.getSeconds(), 0.001);
    
    // Test full unit names
    group = parseArg("1seconds");
    Assert.assertNotNull(group);
    Assert.assertEquals(1, group.size());
    
    token = group.get(0);
    Assert.assertTrue(token instanceof TimeDuration);
    duration = (TimeDuration) token;
    Assert.assertEquals(1.0, duration.getSeconds(), 0.001);
  }
}