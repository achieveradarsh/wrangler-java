package io.cdap.wrangler.steps.transformation;

import io.cdap.wrangler.api.Arguments;
import io.cdap.wrangler.api.Directive;
import io.cdap.wrangler.api.ExecutorContext;
import io.cdap.wrangler.api.Row;
import io.cdap.wrangler.api.parser.ByteSize;
import io.cdap.wrangler.api.parser.ColumnName;
import io.cdap.wrangler.api.parser.Text;
import io.cdap.wrangler.api.parser.TimeDuration;
import io.cdap.wrangler.api.parser.UsageDefinition;
import io.cdap.wrangler.test.TestingRig;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Tests for {@link AggregateStats} directive.
 */
public class AggregateStatsTest {

  /**
   * Mock implementation of ExecutorContext for testing.
   */
  private static class MockExecutorContext implements ExecutorContext {
    private final boolean isLast;

    public MockExecutorContext(boolean isLast) {
      this.isLast = isLast;
    }

    @Override
    public boolean isLast() {
      return isLast;
    }

    // Add other necessary methods from ExecutorContext interface
    // These are just stub implementations
    @Override
    public String getStageName() {
      return "mock-stage";
    }

    @Override
    public Object getStoreGet(String name) {
      return null;
    }

    @Override
    public void putStore(String name, Object value) {
      // Do nothing
    }
  }

  /**
   * Creates a directive instance for testing.
   */
  private AggregateStats createDirective(String sizeColumn, String timeColumn, 
                                        String totalSizeColumn, String totalTimeColumn,
                                        String sizeOutputUnit, String timeOutputUnit,
                                        boolean average) throws Exception {
    AggregateStats directive = new AggregateStats();
    
    // Set up arguments
    Arguments arguments = Mockito.mock(Arguments.class);
    Mockito.when(arguments.value("sizeColumn")).thenReturn(new ColumnName(sizeColumn));
    Mockito.when(arguments.value("timeColumn")).thenReturn(new ColumnName(timeColumn));
    Mockito.when(arguments.value("totalSizeColumn")).thenReturn(new ColumnName(totalSizeColumn));
    Mockito.when(arguments.value("totalTimeColumn")).thenReturn(new ColumnName(totalTimeColumn));
    
    if (sizeOutputUnit != null) {
      Mockito.when(arguments.contains("sizeOutputUnit")).thenReturn(true);
      Mockito.when(arguments.value("sizeOutputUnit")).thenReturn(new Text(sizeOutputUnit));
    }
    
    if (timeOutputUnit != null) {
      Mockito.when(arguments.contains("timeOutputUnit")).thenReturn(true);
      Mockito.when(arguments.value("timeOutputUnit")).thenReturn(new Text(timeOutputUnit));
    }
    
    Mockito.when(arguments.contains("average")).thenReturn(true);
    Mockito.when(arguments.value("average")).thenReturn(average);
    
    // Initialize the directive
    directive.initialize(arguments, new MockExecutorContext(false));
    
    return directive;
  }

  /**
   * Creates test rows with byte size and time duration values.
   */
  private List<Row> createTestRows() {
    List<Row> rows = new ArrayList<>();
    
    // Row 1: 10KB, 100ms
    Row row1 = new Row();
    row1.add("data_transfer_size", new ByteSize("10KB"));
    row1.add("response_time", new TimeDuration("100ms"));
    rows.add(row1);
    
    // Row 2: 20KB, 200ms
    Row row2 = new Row();
    row2.add("data_transfer_size", new ByteSize("20KB"));
    row2.add("response_time", new TimeDuration("200ms"));
    rows.add(row2);
    
    // Row 3: 30KB, 300ms
    Row row3 = new Row();
    row3.add("data_transfer_size", new ByteSize("30KB"));
    row3.add("response_time", new TimeDuration("300ms"));
    rows.add(row3);
    
    // Row 4: 1.5MB, 1.2s
    Row row4 = new Row();
    row4.add("data_transfer_size", new ByteSize("1.5MB"));
    row4.add("response_time", new TimeDuration("1.2s"));
    rows.add(row4);
    
    // Row 5: String values that should be parsed
    Row row5 = new Row();
    row5.add("data_transfer_size", "2MB");
    row5.add("response_time", "500ms");
    rows.add(row5);
    
    return rows;
  }

  @Test
  public void testDefine() {
    AggregateStats directive = new AggregateStats();
    UsageDefinition definition = directive.define();
    
    Assert.assertEquals("aggregate-stats", definition.getName());
    Assert.assertTrue(definition.getArguments().containsKey("sizeColumn"));
    Assert.assertTrue(definition.getArguments().containsKey("timeColumn"));
    Assert.assertTrue(definition.getArguments().containsKey("totalSizeColumn"));
    Assert.assertTrue(definition.getArguments().containsKey("totalTimeColumn"));
    Assert.assertTrue(definition.getArguments().containsKey("sizeOutputUnit"));
    Assert.assertTrue(definition.getArguments().containsKey("timeOutputUnit"));
    Assert.assertTrue(definition.getArguments().containsKey("average"));
  }

  @Test
  public void testTotalAggregation() throws Exception {
    AggregateStats directive = createDirective(
      "data_transfer_size", "response_time", 
      "total_size_mb", "total_time_sec",
      "MB", "S", false);
    
    List<Row> rows = createTestRows();
    
    // Process rows (non-final batch)
    List<Row> result = directive.execute(rows, new MockExecutorContext(false));
    Assert.assertEquals(rows, result); // Should return input rows unchanged
    
    // Process empty final batch
    result = directive.execute(new ArrayList<>(), new MockExecutorContext(true));
    
    // Verify results
    Assert.assertEquals(1, result.size());
    Row resultRow = result.get(0);
    
    Assert.assertTrue(resultRow.has("total_size_mb"));
    Assert.assertTrue(resultRow.has("total_time_sec"));
    
    // Calculate expected values
    // 10KB + 20KB + 30KB + 1.5MB + 2MB = 60KB + 3.5MB ≈ 3.56MB
    double expectedTotalSizeMB = (10 * 1024 + 20 * 1024 + 30 * 1024 + 
                                 1.5 * 1024 * 1024 + 2 * 1024 * 1024) / (1024.0 * 1024.0);
    
    // 100ms + 200ms + 300ms + 1.2s + 500ms = 600ms + 1.2s + 500ms = 2.3s
    double expectedTotalTimeSec = (100 + 200 + 300 + 1200 + 500) / 1000.0;
    
    Assert.assertEquals(expectedTotalSizeMB, (Double) resultRow.getValue("total_size_mb"), 0.001);
    Assert.assertEquals(expectedTotalTimeSec, (Double) resultRow.getValue("total_time_sec"), 0.001);
  }

  @Test
  public void testAverageAggregation() throws Exception {
    AggregateStats directive = createDirective(
      "data_transfer_size", "response_time", 
      "avg_size_kb", "avg_time_ms",
      "KB", "MS", true);
    
    List<Row> rows = createTestRows();
    
    // Process rows (non-final batch)
    directive.execute(rows, new MockExecutorContext(false));
    
    // Process empty final batch
    List<Row> result = directive.execute(new ArrayList<>(), new MockExecutorContext(true));
    
    // Verify results
    Assert.assertEquals(1, result.size());
    Row resultRow = result.get(0);
    
    Assert.assertTrue(resultRow.has("avg_size_kb"));
    Assert.assertTrue(resultRow.has("avg_time_ms"));
    
    // Calculate expected values
    // Average size: (10KB + 20KB + 30KB + 1.5MB + 2MB) / 5 in KB
    double totalBytes = 10 * 1024 + 20 * 1024 + 30 * 1024 + 
                       1.5 * 1024 * 1024 + 2 * 1024 * 1024;
    double expectedAvgSizeKB = (totalBytes / 5) / 1024.0;
    
    // Average time: (100ms + 200ms + 300ms + 1.2s + 500ms) / 5 in ms
    double totalMs = 100 + 200 + 300 + 1200 + 500;
    double expectedAvgTimeMs = totalMs / 5;
    
    Assert.assertEquals(expectedAvgSizeKB, (Double) resultRow.getValue("avg_size_kb"), 0.001);
    Assert.assertEquals(expectedAvgTimeMs, (Double) resultRow.getValue("avg_time_ms"), 0.001);
  }

  @Test
  public void testWithDifferentOutputUnits() throws Exception {
    AggregateStats directive = createDirective(
      "data_transfer_size", "response_time", 
      "total_size_gb", "total_time_min",
      "GB", "M", false);
    
    List<Row> rows = createTestRows();
    
    // Process all rows in one batch
    List<Row> result = directive.execute(rows, new MockExecutorContext(true));
    
    // Verify results
    Assert.assertEquals(1, result.size());
    Row resultRow = result.get(0);
    
    // Calculate expected values in different units
    // Total size in GB: (10KB + 20KB + 30KB + 1.5MB + 2MB) in GB
    double totalBytes = 10 * 1024 + 20 * 1024 + 30 * 1024 + 
                       1.5 * 1024 * 1024 + 2 * 1024 * 1024;
    double expectedTotalSizeGB = totalBytes / (1024.0 * 1024.0 * 1024.0);
    
    // Total time in minutes: (100ms + 200ms + 300ms + 1.2s + 500ms) in minutes
    double totalMs = 100 + 200 + 300 + 1200 + 500;
    double expectedTotalTimeMin = totalMs / (1000.0 * 60.0);
    
    Assert.assertEquals(expectedTotalSizeGB, (Double) resultRow.getValue("total_size_gb"), 0.0001);
    Assert.assertEquals(expectedTotalTimeMin, (Double) resultRow.getValue("total_time_min"), 0.0001);
  }

  @Test
  public void testWithMissingValues() throws Exception {
    AggregateStats directive = createDirective(
      "data_transfer_size", "response_time", 
      "total_size_mb", "total_time_sec",
      "MB", "S", false);
    
    List<Row> rows = new ArrayList<>();
    
    // Row with only size
    Row row1 = new Row();
    row1.add("data_transfer_size", new ByteSize("10KB"));
    rows.add(row1);
    
    // Row with only time
    Row row2 = new Row();
    row2.add("response_time", new TimeDuration("200ms"));
    rows.add(row2);
    
    // Row with neither
    Row row3 = new Row();
    row3.add("other_column", "value");
    rows.add(row3);
    
    // Process rows in final batch
    List<Row> result = directive.execute(rows, new MockExecutorContext(true));
    
    // Verify results
    Assert.assertEquals(1, result.size());
    Row resultRow = result.get(0);
    
    // Only one row had size data (10KB)
    double expectedTotalSizeMB = (10 * 1024) / (1024.0 * 1024.0);
    
    // Only one row had time data (200ms)
    double expectedTotalTimeSec = 200 / 1000.0;
    
    Assert.assertEquals(expectedTotalSizeMB, (Double) resultRow.getValue("total_size_mb"), 0.001);
    Assert.assertEquals(expectedTotalTimeSec, (Double) resultRow.getValue("total_time_sec"), 0.001);
  }

  @Test
  public void testWithTestingRig() throws Exception {
    // Create sample rows
    List<Row> rows = createTestRows();
    
    // Define recipe using the new directive
    String[] recipe = new String[] {
      "aggregate-stats :data_transfer_size :response_time total_size_mb total_time_sec 'MB' 'S' false"
    };
    
    // Execute recipe using TestingRig
    List<Row> results = TestingRig.execute(recipe, rows);
    
    // Verify results
    Assert.assertEquals(1, results.size());
    Row resultRow = results.get(0);
    
    // Calculate expected values
    double totalBytes = 10 * 1024 + 20 * 1024 + 30 * 1024 + 
                       1.5 * 1024 * 1024 + 2 * 1024 * 1024;
    double expectedTotalSizeMB = totalBytes / (1024.0 * 1024.0);
    
    double totalMs = 100 + 200 + 300 + 1200 + 500;
    double expectedTotalTimeSec = totalMs / 1000.0;
    
    Assert.assertEquals(expectedTotalSizeMB, (Double) resultRow.getValue("total_size_mb"), 0.001);
    Assert.assertEquals(expectedTotalTimeSec, (Double) resultRow.getValue("total_time_sec"), 0.001);
  }
}