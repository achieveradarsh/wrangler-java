# CDAP Wrangler Enhanced with ByteSize and TimeDuration Support

This repository contains enhancements to the CDAP Wrangler library, adding support for byte size and time duration unit parsing and aggregation. These enhancements enable more efficient handling of data involving file sizes or time measurements.

## New Features

### ByteSize Parsing and Handling

The ByteSize feature allows parsing and manipulation of byte size values like "1.5KB", "2MB", or "3GB".

Features include:
- Automatic parsing of values with units (B, KB, MB, GB, TB, PB)
- Conversion between different byte size units
- Extraction of numeric values and units
- Standardized formatting methods

### TimeDuration Parsing and Handling

The TimeDuration feature allows parsing and manipulation of time duration values like "100ms", "2s", or "5min".

Features include:
- Automatic parsing of values with units (ns, ms, s, min, h, d)
- Conversion between different time duration units
- Integration with Java's TimeUnit class
- Standardized formatting methods

### New Aggregate-Stats Directive

A new directive `aggregate-stats` has been added that uses the ByteSize and TimeDuration parsers to calculate statistical aggregations on columns containing these value types.

Usage:
```
aggregate-stats <column> <type> <prefix>
```

Where:
- `column` is the column containing byte size or time duration values
- `type` is either 'bytesize' or 'timeduration'
- `prefix` is the prefix for the output statistics columns

See the [aggregate-stats documentation](wrangler-docs/directives/aggregate-stats.md) for more details.

## Implementation Details

The enhancement includes the following components:

1. **Grammar Updates**: Modified the ANTLR4 grammar (`Directives.g4`) to recognize ByteSize and TimeDuration tokens.

2. **New Token Types**: Added BYTE_SIZE and TIME_DURATION to the TokenType enumeration.

3. **Parser Classes**:
   - `ByteSize.java` - Parses and handles byte size values
   - `TimeDuration.java` - Parses and handles time duration values

4. **Visitor Methods**: Added visitor methods in RecipeVisitor to handle the new token types.

5. **New Directive**: Implemented the `AggregateStats` directive that leverages the TransientStore to accumulate statistics on byte size or time duration values.

6. **Documentation and Tests**: Comprehensive test cases and documentation for the new functionality.

## Usage Examples

### ByteSize Parsing

```java
ByteSize size = new ByteSize("1.5GB");
double bytes = size.getBytes();       // 1.5 * 1024 * 1024 * 1024
double mb = size.getMegabytes();      // 1.5 * 1024
String formatted = size.format("MB"); // "1536.00MB"
```

### TimeDuration Parsing

```java
TimeDuration duration = new TimeDuration("2.5min");
double ms = duration.getMilliseconds(); // 2.5 * 60 * 1000
double sec = duration.getSeconds();     // 2.5 * 60
String formatted = duration.format("s"); // "150.00s"
```

### Aggregating Statistics

```
// In a Wrangler recipe
aggregate-stats :file_size 'bytesize' 'size.stats'
```

This will calculate min, max, sum, count, and average statistics for the `file_size` column, with results added to the last row as `size.stats.min`, `size.stats.max`, etc.