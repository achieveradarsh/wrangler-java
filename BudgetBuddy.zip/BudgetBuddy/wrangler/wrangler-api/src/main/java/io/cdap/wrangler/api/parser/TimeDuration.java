/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.wrangler.api.parser;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TimeDuration provides a way to parse and handle time duration representations like 1ms, 2s, 5min, etc.
 * This class parses the input string and converts it to a canonical value in milliseconds.
 */
public class TimeDuration implements Token {
  // Pattern for matching time duration values (e.g., 10ms, 5s, 2.5min)
  private static final Pattern TIME_DURATION_PATTERN = 
      Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(ns|ms|s|min|h|d)?", Pattern.CASE_INSENSITIVE);
  
  // Conversion factors for different time units to milliseconds
  private static final Map<String, Double> UNIT_TO_MS_FACTOR = new HashMap<>();
  static {
    UNIT_TO_MS_FACTOR.put("NS", 0.000001); // nanoseconds to milliseconds
    UNIT_TO_MS_FACTOR.put("MS", 1.0);      // milliseconds
    UNIT_TO_MS_FACTOR.put("S", 1000.0);    // seconds to milliseconds
    UNIT_TO_MS_FACTOR.put("MIN", 60000.0); // minutes to milliseconds
    UNIT_TO_MS_FACTOR.put("H", 3600000.0); // hours to milliseconds
    UNIT_TO_MS_FACTOR.put("D", 86400000.0); // days to milliseconds
  }

  private final String originalValue;
  private final double value;
  private final String unit;
  private final double milliseconds;

  /**
   * Constructor to create a TimeDuration object from a string representation.
   *
   * @param value String representation of time duration (e.g., "10ms", "5s")
   */
  public TimeDuration(String value) {
    this.originalValue = value;
    
    Matcher matcher = TIME_DURATION_PATTERN.matcher(value.trim());
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid time duration format: " + value);
    }
    
    this.value = Double.parseDouble(matcher.group(1));
    this.unit = (matcher.group(2) != null) ? matcher.group(2).toUpperCase() : "MS";
    
    Double factor = UNIT_TO_MS_FACTOR.get(this.unit);
    if (factor == null) {
      throw new IllegalArgumentException("Unknown time duration unit: " + this.unit);
    }
    
    this.milliseconds = this.value * factor;
  }

  /**
   * Gets the original string value.
   *
   * @return the original string representation of the time duration
   */
  public String getOriginalValue() {
    return originalValue;
  }

  /**
   * Gets the numeric value part of the time duration.
   *
   * @return the numeric value
   */
  public double getValue() {
    return value;
  }

  /**
   * Gets the unit part of the time duration (e.g., "ms", "s").
   *
   * @return the unit
   */
  public String getUnit() {
    return unit;
  }

  /**
   * Gets the time duration in nanoseconds.
   *
   * @return the duration in nanoseconds
   */
  public double getNanoseconds() {
    return milliseconds * 1_000_000;
  }

  /**
   * Gets the time duration in milliseconds.
   *
   * @return the duration in milliseconds
   */
  public double getMilliseconds() {
    return milliseconds;
  }

  /**
   * Gets the time duration in seconds.
   *
   * @return the duration in seconds
   */
  public double getSeconds() {
    return milliseconds / 1000.0;
  }

  /**
   * Gets the time duration in minutes.
   *
   * @return the duration in minutes
   */
  public double getMinutes() {
    return milliseconds / 60000.0;
  }

  /**
   * Gets the time duration in hours.
   *
   * @return the duration in hours
   */
  public double getHours() {
    return milliseconds / 3600000.0;
  }

  /**
   * Gets the time duration in days.
   *
   * @return the duration in days
   */
  public double getDays() {
    return milliseconds / 86400000.0;
  }

  /**
   * Gets the time duration in the specified unit.
   *
   * @param unit the unit to convert to (ns, ms, s, min, h, d)
   * @return the duration in the specified unit
   */
  public double getAs(String unit) {
    Double factor = UNIT_TO_MS_FACTOR.get(unit.toUpperCase());
    if (factor == null) {
      throw new IllegalArgumentException("Unknown time duration unit: " + unit);
    }
    return milliseconds / factor;
  }

  /**
   * Converts this time duration to the given TimeUnit.
   *
   * @param timeUnit the TimeUnit to convert to
   * @return the duration in the specified TimeUnit
   */
  public long to(TimeUnit timeUnit) {
    switch (timeUnit) {
      case NANOSECONDS:
        return (long) getNanoseconds();
      case MICROSECONDS:
        return (long) (milliseconds * 1000);
      case MILLISECONDS:
        return (long) milliseconds;
      case SECONDS:
        return (long) getSeconds();
      case MINUTES:
        return (long) getMinutes();
      case HOURS:
        return (long) getHours();
      case DAYS:
        return (long) getDays();
      default:
        throw new IllegalArgumentException("Unsupported TimeUnit: " + timeUnit);
    }
  }

  /**
   * Formats the time duration as a string with the specified unit.
   *
   * @param unit the unit to use for formatting
   * @return a formatted string representation
   */
  public String format(String unit) {
    return String.format("%.2f%s", getAs(unit), unit);
  }

  @Override
  public TokenType type() {
    return TokenType.TIME_DURATION;
  }

  @Override
  public String toString() {
    return originalValue;
  }
  
  @Override
  public JsonElement toJson() {
    JsonObject object = new JsonObject();
    object.addProperty("type", type().name());
    object.addProperty("value", originalValue);
    object.addProperty("milliseconds", milliseconds);
    object.addProperty("unit", unit);
    return object;
  }
}