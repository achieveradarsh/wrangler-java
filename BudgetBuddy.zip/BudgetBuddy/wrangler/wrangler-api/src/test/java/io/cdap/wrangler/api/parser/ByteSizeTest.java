/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.wrangler.api.parser;

import org.junit.Assert;
import org.junit.Test;

/**
 * Tests for {@link ByteSize} class.
 */
public class ByteSizeTest {

  @Test
  public void testBasicParsing() {
    ByteSize size = new ByteSize("1024KB");
    Assert.assertEquals(1024, size.getValue(), 0.001);
    Assert.assertEquals("KB", size.getUnit());
    Assert.assertEquals(1024 * 1024, size.getBytes(), 0.001);
    Assert.assertEquals(1024, size.getKilobytes(), 0.001);
    Assert.assertEquals(1, size.getMegabytes(), 0.001);
  }

  @Test
  public void testUnitConversions() {
    ByteSize size = new ByteSize("2.5GB");
    Assert.assertEquals(2.5, size.getValue(), 0.001);
    Assert.assertEquals("GB", size.getUnit());
    Assert.assertEquals(2.5 * 1024 * 1024 * 1024, size.getBytes(), 0.001);
    Assert.assertEquals(2.5 * 1024 * 1024, size.getKilobytes(), 0.001);
    Assert.assertEquals(2.5 * 1024, size.getMegabytes(), 0.001);
    Assert.assertEquals(2.5, size.getGigabytes(), 0.001);
    Assert.assertEquals(2.5 / 1024, size.getTerabytes(), 0.001);
  }

  @Test
  public void testDefaultUnit() {
    ByteSize size = new ByteSize("1024");
    Assert.assertEquals(1024, size.getValue(), 0.001);
    Assert.assertEquals("B", size.getUnit());
    Assert.assertEquals(1024, size.getBytes(), 0.001);
  }

  @Test
  public void testCaseInsensitiveUnits() {
    ByteSize size1 = new ByteSize("1024kb");
    ByteSize size2 = new ByteSize("1024KB");
    Assert.assertEquals(size1.getBytes(), size2.getBytes(), 0.001);
  }

  @Test
  public void testGetAs() {
    ByteSize size = new ByteSize("1GB");
    Assert.assertEquals(1, size.getAs("GB"), 0.001);
    Assert.assertEquals(1024, size.getAs("MB"), 0.001);
    Assert.assertEquals(1024 * 1024, size.getAs("KB"), 0.001);
    Assert.assertEquals(1024 * 1024 * 1024, size.getAs("B"), 0.001);
  }

  @Test
  public void testFormatting() {
    ByteSize size = new ByteSize("1GB");
    Assert.assertEquals("1.00GB", size.format("GB"));
    Assert.assertEquals("1024.00MB", size.format("MB"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidFormat() {
    new ByteSize("1XB"); // Invalid unit
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidValue() {
    new ByteSize("not-a-number-KB");
  }

  @Test
  public void testTokenType() {
    ByteSize size = new ByteSize("1KB");
    Assert.assertEquals(TokenType.BYTE_SIZE, size.type());
  }

  @Test
  public void testToString() {
    String original = "1024KB";
    ByteSize size = new ByteSize(original);
    Assert.assertEquals(original, size.toString());
  }
}