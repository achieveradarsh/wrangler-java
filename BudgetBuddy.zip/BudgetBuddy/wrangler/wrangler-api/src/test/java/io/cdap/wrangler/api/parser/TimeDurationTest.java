/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.wrangler.api.parser;

import org.junit.Assert;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

/**
 * Tests for {@link TimeDuration} class.
 */
public class TimeDurationTest {

  @Test
  public void testBasicParsing() {
    TimeDuration duration = new TimeDuration("1000ms");
    Assert.assertEquals(1000, duration.getValue(), 0.001);
    Assert.assertEquals("MS", duration.getUnit());
    Assert.assertEquals(1000, duration.getMilliseconds(), 0.001);
    Assert.assertEquals(1, duration.getSeconds(), 0.001);
  }

  @Test
  public void testUnitConversions() {
    TimeDuration duration = new TimeDuration("2.5min");
    Assert.assertEquals(2.5, duration.getValue(), 0.001);
    Assert.assertEquals("MIN", duration.getUnit());
    Assert.assertEquals(2.5 * 60 * 1000, duration.getMilliseconds(), 0.001);
    Assert.assertEquals(2.5 * 60, duration.getSeconds(), 0.001);
    Assert.assertEquals(2.5, duration.getMinutes(), 0.001);
    Assert.assertEquals(2.5 / 60, duration.getHours(), 0.001);
  }

  @Test
  public void testDefaultUnit() {
    TimeDuration duration = new TimeDuration("1000");
    Assert.assertEquals(1000, duration.getValue(), 0.001);
    Assert.assertEquals("MS", duration.getUnit());
    Assert.assertEquals(1000, duration.getMilliseconds(), 0.001);
  }

  @Test
  public void testCaseInsensitiveUnits() {
    TimeDuration duration1 = new TimeDuration("1s");
    TimeDuration duration2 = new TimeDuration("1S");
    Assert.assertEquals(duration1.getMilliseconds(), duration2.getMilliseconds(), 0.001);
  }

  @Test
  public void testGetAs() {
    TimeDuration duration = new TimeDuration("60s");
    Assert.assertEquals(60, duration.getAs("s"), 0.001);
    Assert.assertEquals(1, duration.getAs("min"), 0.001);
    Assert.assertEquals(60000, duration.getAs("ms"), 0.001);
  }

  @Test
  public void testTimeUnitConversion() {
    TimeDuration duration = new TimeDuration("60s");
    Assert.assertEquals(60, duration.to(TimeUnit.SECONDS));
    Assert.assertEquals(60 * 1000, duration.to(TimeUnit.MILLISECONDS));
    Assert.assertEquals(1, duration.to(TimeUnit.MINUTES));
  }

  @Test
  public void testFormatting() {
    TimeDuration duration = new TimeDuration("60s");
    Assert.assertEquals("60.00s", duration.format("s"));
    Assert.assertEquals("1.00min", duration.format("min"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidFormat() {
    new TimeDuration("1x"); // Invalid unit
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidValue() {
    new TimeDuration("not-a-number-s");
  }

  @Test
  public void testTokenType() {
    TimeDuration duration = new TimeDuration("1s");
    Assert.assertEquals(TokenType.TIME_DURATION, duration.type());
  }

  @Test
  public void testToString() {
    String original = "1000ms";
    TimeDuration duration = new TimeDuration(original);
    Assert.assertEquals(original, duration.toString());
  }
}