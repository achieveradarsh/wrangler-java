/*
 * Copyright © 2017-2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package io.cdap.directives.aggregator;

import io.cdap.directives.aggregates.DefaultTransientStore;
import io.cdap.wrangler.api.ExecutorContext;
import io.cdap.wrangler.api.Row;
import io.cdap.wrangler.api.TransientStore;
import io.cdap.wrangler.parser.ConfigDirectiveContext;
import io.cdap.wrangler.parser.TextDirective;
import io.cdap.wrangler.test.TestingRig;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;

/**
 * Tests for {@link AggregateStats} directive.
 */
public class AggregateStatsTest {

  @Test
  public void testByteSizeAggregation() throws Exception {
    String directive = "aggregate-stats :size 'bytesize' 'size.stats'";
    
    List<Row> rows = new ArrayList<>();
    Row row1 = new Row();
    row1.add("size", "1024B");
    
    Row row2 = new Row();
    row2.add("size", "2KB");
    
    Row row3 = new Row();
    row3.add("size", "3MB");
    
    rows.add(row1);
    rows.add(row2);
    rows.add(row3);
    
    // Mock the ExecutorContext
    ExecutorContext context = Mockito.mock(ExecutorContext.class);
    TransientStore store = new DefaultTransientStore();
    when(context.getTransientStore()).thenReturn(store);
    
    // Process the rows with the directive
    TestingRig rig = new TestingRig(Arrays.asList(new TextDirective(directive)), context);
    List<Row> results = rig.execute(rows);
    
    // The last row should have the aggregated statistics
    Row lastRow = results.get(results.size() - 1);
    
    // Verify the count is correct
    Assert.assertEquals(3L, lastRow.getValue("size.stats.count"));
    
    // Verify statistics were generated
    Assert.assertNotNull(lastRow.getValue("size.stats.min"));
    Assert.assertNotNull(lastRow.getValue("size.stats.max"));
    Assert.assertNotNull(lastRow.getValue("size.stats.sum"));
    Assert.assertNotNull(lastRow.getValue("size.stats.avg"));
  }

  @Test
  public void testTimeDurationAggregation() throws Exception {
    String directive = "aggregate-stats :duration 'timeduration' 'time.stats'";
    
    List<Row> rows = new ArrayList<>();
    Row row1 = new Row();
    row1.add("duration", "100ms");
    
    Row row2 = new Row();
    row2.add("duration", "2s");
    
    Row row3 = new Row();
    row3.add("duration", "1min");
    
    rows.add(row1);
    rows.add(row2);
    rows.add(row3);
    
    // Mock the ExecutorContext
    ExecutorContext context = Mockito.mock(ExecutorContext.class);
    TransientStore store = new DefaultTransientStore();
    when(context.getTransientStore()).thenReturn(store);
    
    // Process the rows with the directive
    TestingRig rig = new TestingRig(Arrays.asList(new TextDirective(directive)), context);
    List<Row> results = rig.execute(rows);
    
    // The last row should have the aggregated statistics
    Row lastRow = results.get(results.size() - 1);
    
    // Verify the count is correct
    Assert.assertEquals(3L, lastRow.getValue("time.stats.count"));
    
    // Verify statistics were generated
    Assert.assertNotNull(lastRow.getValue("time.stats.min"));
    Assert.assertNotNull(lastRow.getValue("time.stats.max"));
    Assert.assertNotNull(lastRow.getValue("time.stats.sum"));
    Assert.assertNotNull(lastRow.getValue("time.stats.avg"));
  }

  @Test
  public void testHandlesNullValues() throws Exception {
    String directive = "aggregate-stats :size 'bytesize' 'size.stats'";
    
    List<Row> rows = new ArrayList<>();
    Row row1 = new Row();
    row1.add("size", "1024B");
    
    Row row2 = new Row();
    row2.add("size", null);
    
    Row row3 = new Row();
    row3.add("size", "3MB");
    
    rows.add(row1);
    rows.add(row2);
    rows.add(row3);
    
    // Mock the ExecutorContext
    ExecutorContext context = Mockito.mock(ExecutorContext.class);
    TransientStore store = new DefaultTransientStore();
    when(context.getTransientStore()).thenReturn(store);
    
    // Process the rows with the directive
    TestingRig rig = new TestingRig(Arrays.asList(new TextDirective(directive)), context);
    List<Row> results = rig.execute(rows);
    
    // The last row should have the aggregated statistics
    Row lastRow = results.get(results.size() - 1);
    
    // Verify the count is correct (should be 2, not 3 because of the null value)
    Assert.assertEquals(2L, lastRow.getValue("size.stats.count"));
  }

  @Test
  public void testNoTransientStore() throws Exception {
    String directive = "aggregate-stats :size 'bytesize' 'size.stats'";
    
    List<Row> rows = new ArrayList<>();
    Row row = new Row();
    row.add("size", "1024B");
    rows.add(row);
    
    // Create a ExecutorContext with no TransientStore
    ExecutorContext context = Mockito.mock(ExecutorContext.class);
    when(context.getTransientStore()).thenReturn(null);
    
    // This should throw an exception
    boolean exceptionThrown = false;
    try {
      TestingRig rig = new TestingRig(Arrays.asList(new TextDirective(directive)), context);
      rig.execute(rows);
    } catch (Exception e) {
      exceptionThrown = true;
      Assert.assertTrue(e.getMessage().contains("Transient store is not available"));
    }
    
    Assert.assertTrue("Expected exception was not thrown", exceptionThrown);
  }
}