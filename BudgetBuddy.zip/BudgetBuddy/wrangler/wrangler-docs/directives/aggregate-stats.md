# aggregate-stats

The `aggregate-stats` directive calculates statistical aggregations on columns containing byte size values or time duration values.

## Syntax

```
aggregate-stats <column> <type> <prefix>
```

## Arguments

- **column**: The column containing the values to aggregate (must be of byte size or time duration format).
- **type**: The type of values to aggregate, either 'bytesize' or 'timeduration'.
- **prefix**: A prefix to use for the generated statistics columns.

## Usage Notes

The `aggregate-stats` directive processes each row and accumulates statistics for the values in the specified column. It generates the following statistics:

- **{prefix}.count**: The number of non-null values processed.
- **{prefix}.min**: The minimum value encountered.
- **{prefix}.max**: The maximum value encountered.
- **{prefix}.sum**: The sum of all values.
- **{prefix}.avg**: The average value (sum / count).

The statistics are added as new columns to the last row in the dataset.

### Byte Size Values

For byte size aggregation, the directive recognizes values in the following formats:
- `<number>B` (Bytes)
- `<number>KB` (Kilobytes)
- `<number>MB` (Megabytes)
- `<number>GB` (Gigabytes)
- `<number>TB` (Terabytes)
- `<number>PB` (Petabytes)

All values are normalized to bytes before aggregation, and the results are formatted in appropriate units based on their magnitude.

### Time Duration Values

For time duration aggregation, the directive recognizes values in the following formats:
- `<number>ns` (Nanoseconds)
- `<number>us` (Microseconds)
- `<number>ms` (Milliseconds)
- `<number>s` (Seconds)
- `<number>min` (Minutes)
- `<number>h` (Hours)
- `<number>d` (Days)

All values are normalized to milliseconds before aggregation, and the results are formatted in appropriate units based on their magnitude.

## Examples

### Byte Size Aggregation

```
aggregate-stats :filesize 'bytesize' 'size.stats'
```

This will process the `filesize` column containing byte size values like "10KB", "4.5MB", etc., and will add statistics columns with the prefix `size.stats`. The last row will have new columns:

- `size.stats.count`
- `size.stats.min`
- `size.stats.max`
- `size.stats.sum`
- `size.stats.avg`

### Time Duration Aggregation

```
aggregate-stats :response_time 'timeduration' 'time.stats'
```

This will process the `response_time` column containing time duration values like "150ms", "2.5s", etc., and will add statistics columns with the prefix `time.stats`. The last row will have new columns:

- `time.stats.count`
- `time.stats.min`
- `time.stats.max`
- `time.stats.sum`
- `time.stats.avg`